package com.samsung.accessory.FTSampleProvider.ui;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.os.StrictMode;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.doreso.sdk.DoresoConfig;
import com.doreso.sdk.DoresoListener;
import com.doreso.sdk.DoresoManager;
import com.doreso.sdk.utils.DoresoMusicTrack;
import com.j256.ormlite.android.apptools.OrmLiteBaseActivity;
import com.j256.ormlite.dao.RuntimeExceptionDao;
import com.samsung.accessory.FTSampleProvider.R;
import com.samsung.accessory.FTSampleProvider.backend.FTSampleProviderImpl;
import com.samsung.accessory.FTSampleProvider.backend.FTSampleProviderImpl.FileAction;
import com.samsung.accessory.FTSampleProvider.backend.FTSampleProviderImpl.LocalBinder;
import com.samsung.accessory.FTSampleProvider.entities.Chanson;
import com.samsung.accessory.FTSampleProvider.utils.DatabaseHelper;
import com.samsung.android.sdk.accessory.SASocket;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FTSampleProviderActivity extends OrmLiteBaseActivity<DatabaseHelper> {
    private static final String TAG = "ProviderActivity";
    private static final String DEST_PATH  = "/storage/emulated/legacy/temp.aaa";
    private static final String DEST_DIRECTORY = "/storage/emulated/legacy/";

    public static boolean isUp = false;
    public String mp3path;
    private Context mCtxt;
    private ProgressBar mRecvProgressBar;
    private Button btn ;
    private Button btnDoreso ;
    private String mDirPath;
    private AlertDialog mAlert;
    private String mFilePath;
    public int mTransId;
    public static boolean w=false;

    public static String artiste ;
    public static String titre ;
    public static String  album;

    private FTSampleProviderImpl.FTSampleProviderConnection mConnection = null;
    public static final int HELLOACCESSORY_CHANNEL_ID = 107;
    HashMap<Integer, FTSampleProviderImpl.FTSampleProviderConnection> mConnectionsMap = null;
    int mConnectionId;

    public File fileamr = new File("/storage/emulated/0/www.amr");
    final private static String APPKEY = "HEhxCVboznWPBIB8APPUcm06kv5x3zvLx3xVerMLg4I";
    final private static String APPSECRET = "e14bb5499bd8457b82d45d1a8414376e";


    private FTSampleProviderImpl mFTService;

    private ServiceConnection mFTConnection = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            Log.d(TAG, "FT service connection lost");
            mFTService = null;
        }

        @Override
        public void onServiceConnected(ComponentName arg0, IBinder service) {
            Log.d(TAG, "FT service connected");
            mFTService = ((LocalBinder) service).getService();
            mFTService.registerFileAction(getFileAction());
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ft_provider_activity);
        isUp = true;
        mCtxt = getApplicationContext();

        btn = (Button) findViewById(R.id.btnOk);
        btnDoreso = (Button) findViewById(R.id.btnDoreso);
         artiste ="-";
         titre ="-";
          album="-";


        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder()
                .permitAll().build();
        StrictMode.setThreadPolicy(policy);

        mConnectionId = (int) (System.currentTimeMillis() & 255);
        mConnectionsMap = new HashMap<Integer, FTSampleProviderImpl.FTSampleProviderConnection>();

        btnDoreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(FTSampleProviderActivity.this,DoresoMainActivity.class);
                startActivity(i);

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(FTSampleProviderActivity.this,ListTag.class);
                startActivity(i);

            }
        });

        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            Toast.makeText(mCtxt, " No SDCARD Present ", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            mDirPath = Environment.getExternalStorageDirectory() + File.separator + "FTSampleProvider";
            File file = new File(mDirPath);
            if (file.mkdirs()) {
                Toast.makeText(mCtxt, " Stored in " + mDirPath, Toast.LENGTH_LONG).show();
            }
        }

        mCtxt.bindService(new Intent(getApplicationContext(), FTSampleProviderImpl.class),
                this.mFTConnection, Context.BIND_AUTO_CREATE);
    }

    public void onDestroy() {
        isUp = false;
        super.onDestroy();
    }

    @Override
    protected void onStart() {
        isUp = true;
        super.onStart();
    }

    @Override
    protected void onStop() {
        isUp = false;
        super.onStop();
    }

    @Override
    public void onBackPressed() {
        isUp=false;
        moveTaskToBack(true);
    }

    // for Android before 2.0, just in case
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            isUp=false;
            moveTaskToBack(true);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onPause() {
        isUp = false;
        super.onPause();
    }

    @Override
    protected void onResume() {
        isUp = true;
        super.onResume();
    }

    private FileAction getFileAction() {
        return new FileAction() {
            @Override
            public void onError(final String errorMsg,final int errorCode) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mAlert != null && mAlert.isShowing()) {
                            mAlert.dismiss();
                        }
                        Toast.makeText(mCtxt, "Transfer cancelled " + errorMsg, Toast.LENGTH_SHORT).show();
                        titre="-";

                    }
                });
            }

            @Override
            public void onProgress(final long progress) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//
                    }
                });
            }

            @Override
            public void onTransferComplete(final String path) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.e(TAG,"path "+path);
                        mp3path = path;
                        mAlert.dismiss();
                        Toast.makeText(getBaseContext(), "receive Completed!", Toast.LENGTH_SHORT).show();
                        titre="-";
                        doreso(fileamr);
                        Intent i = new Intent(FTSampleProviderActivity.this,ListTag.class);
                        startActivity(i);
                    }
                });
            }
            @Override
            public void onTransferRequested(int id, String path) {
                mFilePath = path;
                mTransId = id;
                try {
                    fileamr.delete();
                    String receiveFileName = mFilePath.substring(mFilePath.lastIndexOf("/"), mFilePath.length());
                    mFTService.receiveFile(mTransId, DEST_DIRECTORY + receiveFileName , true);
                    Log.i(TAG, "sending accepted");

                    showQuitDialog();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(mCtxt, "IllegalArgumentException", Toast.LENGTH_SHORT).show();
                }
            }
        };
    }

    private void showQuitDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AlertDialog.Builder alertbox = new AlertDialog.Builder(FTSampleProviderActivity.this);
                alertbox = new AlertDialog.Builder(FTSampleProviderActivity.this);
                alertbox.setMessage("Receiving file : [" + mFilePath + "] QUIT?");
                alertbox.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        try {
                            mFTService.cancelFileTransfer(mTransId);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(mCtxt, "IllegalArgumentException", Toast.LENGTH_SHORT).show();
                        }
                        mAlert.dismiss();
                        mRecvProgressBar.setProgress(0);
                    }
                });
                alertbox.setCancelable(false);
                mAlert = alertbox.create();
                mAlert.show();
            }
        });
    }


    public void doreso (File file) {
        String url = "http://developer.doreso.com/api/v1/song/identify";
        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httpost = new HttpPost(url);
            MultipartEntity reqentity = new MultipartEntity();
            reqentity.addPart("api_key", new StringBody(APPKEY));
            reqentity.addPart("track", new FileBody(file));
            httpost.setEntity(reqentity);
            HttpResponse response;
            response = httpclient.execute(httpost);
            HttpEntity entity = response.getEntity();

            try {
                String content = EntityUtils.toString(entity);
                Log.e("Response", content);

                JSONObject chans = new JSONObject(content);
                JSONArray chansD = chans.getJSONArray("data");
                if (chansD != null) {
                    try {
                        JSONObject c = chansD.getJSONObject(0);
                        titre = c.getString("name");
                        album = c.getString("album");
                        artiste = c.getString("artist_name");
                        System.out.println("titre: " + titre + " album: " + album + " artiste: " + artiste);
                        Toast.makeText(mCtxt, titre + " - " + artiste, Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else{
                    artiste ="-";
                    titre ="-";
                    album="-";
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (titre=="-") {
                Toast.makeText(mCtxt, "error", Toast.LENGTH_LONG).show();
            } else {
                //insert in db
                RuntimeExceptionDao<Chanson, Integer> chansonDao = getHelper().getProdRuntimeExceptionDao();
                chansonDao.create(new Chanson(titre, artiste, album));
                List<Chanson> ch = chansonDao.queryForAll();
                Log.d("ORMLite", ch.toString());

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void sendDataToGear() {
        Log.d("Send Notification", ""+titre);
        Intent intent = new Intent("myData");
        intent.putExtra("data", titre+" - "+artiste);
        sendBroadcast(intent);
    }

}


