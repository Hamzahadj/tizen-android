package com.samsung.accessory.FTSampleProvider.utils;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;


import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.RuntimeExceptionDao;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;
import com.samsung.accessory.FTSampleProvider.R;
import com.samsung.accessory.FTSampleProvider.entities.Chanson;

import java.sql.SQLException;

public class DatabaseHelper extends OrmLiteSqliteOpenHelper{

	private static final String DATABASE_NAME="Tizam";
	
	private static final int DATABASE_VERSION=1;
	

	
	private Dao<Chanson, Integer> prodDao=null;
	private RuntimeExceptionDao<Chanson, Integer> prodRuntimeDao = null;
	
	public DatabaseHelper(Context context){
		super(context, DATABASE_NAME, null, DATABASE_VERSION, R.raw.db_conf);
	}


	@Override
	public void onCreate(SQLiteDatabase database, ConnectionSource connectionSource) {
		try {

			TableUtils.createTable(connectionSource, Chanson.class);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	@Override
	public void onUpgrade(SQLiteDatabase database, ConnectionSource connectionSource, int oldVersion,
			int newVersion) {
		try {
			TableUtils.dropTable(connectionSource, Chanson.class, true);
			onCreate(database,connectionSource);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public Dao<Chanson,Integer>getDao(){
		if(prodDao==null){
			try {
				prodDao = getDao(Chanson.class);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return prodDao;
	}
	
	public RuntimeExceptionDao<Chanson, Integer> getProdRuntimeExceptionDao(){
		if(prodRuntimeDao==null){
			prodRuntimeDao= getRuntimeExceptionDao(Chanson.class);
		}
		return prodRuntimeDao;
	}

}
