package com.samsung.accessory.FTSampleProvider.ui;


import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;

import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Intent;
import android.view.View;


import com.j256.ormlite.android.apptools.OrmLiteBaseActivity;
import com.j256.ormlite.dao.RuntimeExceptionDao;
import com.samsung.accessory.FTSampleProvider.R;
import com.samsung.accessory.FTSampleProvider.entities.Chanson;
import com.samsung.accessory.FTSampleProvider.utils.DatabaseHelper;

import java.util.List;

public class ListTag extends OrmLiteBaseActivity<DatabaseHelper> implements OnItemClickListener{

    public List<Chanson> ch ;
    public AlertDialog.Builder alertbox;
    public AlertDialog.Builder alertbox2;
    private ListView listag;
    private String x= null;
    private String s= null;
    public RuntimeExceptionDao<Chanson,Integer> chansonDao;
    public AlertDialog mAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_tag);
        alertbox= new AlertDialog.Builder(ListTag.this);
        alertbox2= new AlertDialog.Builder(ListTag.this);
        listag = (ListView) findViewById(R.id.listTags);
        chansonDao=getHelper().getProdRuntimeExceptionDao();

        ch = chansonDao.queryForAll();
        Log.d("ORMLite", ch.toString());
        final ListAdapter adapter = new ListAdapter(getApplicationContext(),ch);
        System.out.println("chonson" + ch);
        listag.setAdapter(adapter);
        listag.setOnItemClickListener(this);
}

        @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_list_tag, menu);
        return true;
    }





    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long id) {

        s = "Name: " + ch.get(i).getTitre() + "\nArtiste: " + ch.get(i).getArtiste() + "\nAlbum: " + ch.get(i).getAlbum();
        x = ch.get(i).getTitre() + " - " + ch.get(i).getArtiste();
        alertbox.setMessage("Name: " + ch.get(i).getTitre() + "\nArtiste: " + ch.get(i).getArtiste() + "\nAlbum: " + ch.get(i).getAlbum());
        alertbox.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        mAlert.dismiss();
                    }
                });


        alertbox.setNegativeButton("Share",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        mAlert.dismiss();

                        Intent sharingIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        sharingIntent.setType("text/html");
                        sharingIntent.putExtra(Intent.EXTRA_HTML_TEXT,s);
                        startActivity(Intent.createChooser(sharingIntent, "Share Song :" + " " + x));

                    }
                });
        alertbox.setCancelable(false);
        mAlert = alertbox.create();
        mAlert.show();

    }
}
