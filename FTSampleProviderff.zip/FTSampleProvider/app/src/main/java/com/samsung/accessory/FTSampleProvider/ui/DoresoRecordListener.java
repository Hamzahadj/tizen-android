package com.samsung.accessory.FTSampleProvider.ui;

public interface DoresoRecordListener {
	
	/**
	 * Enregistrement en temps réel des fragments de données
	 * @param buffer
	 */
	public abstract void onRecording(byte[] buffer);
	
	
	/**
	 * enregistrement anormale
	 * @param errorcode
	 * @param msg
	 */
	public abstract void onRecordError(int errorcode, String msg);

	/**
	 * fin d'enregistrement
	 */
	public abstract void onRecordEnd();
}
