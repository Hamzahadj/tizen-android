package com.samsung.accessory.FTSampleProvider.ui;


import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


import com.samsung.accessory.FTSampleProvider.entities.Chanson;
import com.doreso.sdk.DoresoConfig;
import com.doreso.sdk.DoresoListener;
import com.doreso.sdk.DoresoManager;
import com.doreso.sdk.utils.DoresoMusicTrack;
import com.doreso.sdk.utils.DoresoUtils;
import com.doreso.sdk.utils.Logger;
import com.samsung.accessory.FTSampleProvider.utils.DatabaseHelper;

import com.j256.ormlite.android.apptools.OrmLiteBaseActivity;
import com.j256.ormlite.dao.RuntimeExceptionDao;
import com.samsung.accessory.FTSampleProvider.R;

import java.io.InputStream;
import java.util.List;

public class DoresoMainActivity extends OrmLiteBaseActivity<DatabaseHelper> implements DoresoRecordListener,
        DoresoListener {

	private final String TAG = "DoresoMainActivity";
    DatabaseHelper dbHelper;


	private TextView mResult;
	public static DoresoManager mDoresoManager;
	private DoresoRecord mDoresoRecord;
	private boolean mProcessing;

	final private static String APPKEY = "HEhxCVboznWPBIB8APPUcm06kv5x3zvLx3xVerMLg4I";
	final private static String APPSECRET = "e14bb5499bd8457b82d45d1a8414376e";

	private DoresoConfig mConfig;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mConfig = new DoresoConfig();
		mConfig.appkey = APPKEY;
		mConfig.appSecret = APPSECRET;
		mConfig.listener = this;
		mConfig.context = this;
		mDoresoManager = new DoresoManager(mConfig);
		mDoresoRecord = new DoresoRecord(this, 10 * 1000);


		mResult = (TextView) findViewById(R.id.result);


		findViewById(R.id.start).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				start();
			}
		});


	}

	@Override
	protected void onPause() {
		super.onPause();
		mDoresoRecord.reqCancel();
		//mDoresoManager.cancel();
	}

	public void start() {
		mResult.setText("");
		findViewById(R.id.loadingPanel).setVisibility(View.VISIBLE);
		if (!mProcessing) {
			mProcessing = true;
			//mResult.setText(getResources().getString(R.string.recording));
			if (mDoresoRecord!=null) {
				mDoresoRecord.reqCancel();
				mDoresoRecord = null;
			}
			mDoresoRecord = new DoresoRecord(this, 10*1024);
			mDoresoRecord.start();
			if (!mDoresoManager.startRecognize()) {
				Toast.makeText(this, "No network, is not recognized", Toast.LENGTH_SHORT).show();
			}
		}
	}

	protected void stop() {
		if (mProcessing) {
			mDoresoRecord.reqStop();
		} else {
			Toast.makeText(getApplicationContext(),
					getResources().getString(R.string.clickrecord),
					Toast.LENGTH_SHORT).show();
		}
	}

	protected void cancel() {
		if (mProcessing) {
		//	mDoresoManager.cancel();
			mProcessing = false;
		} else {
			Toast.makeText(getApplicationContext(),
					getResources().getString(R.string.clickrecord),
					Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	public void onRecording(byte[] buffer) {
		double volume = DoresoUtils.computeDb(buffer, buffer.length);

		mDoresoManager.doRecognize(buffer);
	}

	@Override
	public void onRecordEnd() {
		mDoresoManager.stopRecognize();
		// mResult.setText(getResources().getString(R.string.recordend));
		mProcessing = false;
	}

	class Mp3Recognizer extends Thread {

		@Override
		public void run() {
			super.run();


			//path to recognize
            String mp3path = Environment.getExternalStorageDirectory()
					.getAbsolutePath().toString()
					+ "/test.mp3";
			mDoresoManager.recognize_mp3(mp3path);
		}
	}




	private byte[] getFromAssets(String fileName) {
		byte[] buffer = new byte[] {};
		try {
			InputStream iStream = getResources().getAssets().open(fileName);
			int length = iStream.available();
			buffer = new byte[length];
			iStream.read(buffer, 0, length);
			iStream.close();
			return buffer;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return buffer;
	}

	@Override
	public void onRecognizeSuccess(DoresoMusicTrack[] tracks, String result) {

		mDoresoManager.stopRecognize();
		findViewById(R.id.loadingPanel).setVisibility(View.GONE);
        //msg à envoyer
		mResult.setText(
				getResources().getString(R.string.artist)
				+ tracks[0].getArtist()+ "\n"
				+ getResources().getString(R.string.title)
				+ tracks[0].getName() + "\n"
				+ getResources().getString(R.string.album)
				+tracks[0].getAlbum());
		mProcessing = false;
        Toast.makeText(this, tracks[0].getName()+" - "+tracks[0].getArtist(), Toast.LENGTH_SHORT).show();

       //insert in db

        RuntimeExceptionDao<Chanson,Integer> chansonDao=getHelper().getProdRuntimeExceptionDao();
        chansonDao.create(new Chanson(tracks[0].getName()+"",tracks[0].getArtist()+"",tracks[0].getAlbum()+""));
        List<Chanson> ch = chansonDao.queryForAll();
        Log.d(TAG, ch.toString());
        Log.d(TAG,"waliiiiiiid "+tracks[0].getName());

	}

	@Override
	public void onRecognizeFail(int errorcode, String msg) {
		mDoresoManager.cancel();
        FTSampleProviderActivity.artiste="-";
        FTSampleProviderActivity.album="-";
        FTSampleProviderActivity.titre="-";
		findViewById(R.id.loadingPanel).setVisibility(View.GONE);
		mResult.setText("Music not found");
		mProcessing = false;
	}

	@Override
	public void onRecognizeEnd() {
		Log.e(TAG, "onRecognizeEnd");
		mProcessing = false;
		mDoresoRecord.reqCancel();
	}

	@Override
	public void onRecordError(int errorcode, String msg) {
		Log.e(TAG, "onRecordError:" + msg + "//" + errorcode);
	}
}
