

package com.samsung.accessory.FTSampleProvider.backend;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Toast;


import com.samsung.accessory.FTSampleProvider.ui.FTSampleProviderActivity;
import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.accessory.SAAgent;
import com.samsung.android.sdk.accessory.SAPeerAgent;
import com.samsung.android.sdk.accessory.SASocket;
import com.samsung.android.sdk.accessoryfiletransfer.SAFileTransfer;
import com.samsung.android.sdk.accessoryfiletransfer.SAFileTransfer.EventListener;
import com.samsung.android.sdk.accessoryfiletransfer.SAft;


import java.io.ByteArrayInputStream;

import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import javax.security.cert.X509Certificate;
import java.lang.*;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.PackageManager.NameNotFoundException;

import com.samsung.android.sdk.accessory.SA;
import com.samsung.android.sdk.accessory.SAAuthenticationToken;




public class FTSampleProviderImpl extends SAAgent  {
    private static final String TAG = "FTSampleProviderImpl";
    public static final int MSG_PUSHFILE_ACCEPTED = 1;
    public static final int MSG_PUSHFILE_NOT_ACCEPTED = 2;


    private FileAction mFileAction = null;

    private final IBinder mBinder = new LocalBinder();
    private FTSampleProviderConnection mConnection = null;
    private SAFileTransfer mSAFileTransfer = null;
    private EventListener mCallback;

    private Context mContext;

    //**hamza**//

    public Boolean isAuthentication = false;
    public static String val="";
    public static final int SERVICE_CONNECTION_RESULT_OK = 0;
    public static final int HELLOACCESSORY_CHANNEL_ID = 107;
    HashMap<Integer, FTSampleProviderConnection> mConnectionsMap = null;
    private int authCount = 1;

    // private Context mContext;

    public FTSampleProviderImpl() {
        super("FTSampleProviderImpl", FTSampleProviderConnection.class);
    }

    public class LocalBinder extends Binder {
        public FTSampleProviderImpl getService() {
            return FTSampleProviderImpl.this;
        }
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return mBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = getApplicationContext();
        Log.d(TAG, "On Create of Sample Provider Service");



        mCallback = new EventListener() {
            @Override
            public void onProgressChanged(int transId, int progress) {
                Log.d(TAG, "onTransferProgress : " + progress + " transId : " + transId);

                if (mFileAction != null) {
                    mFileAction.onProgress(progress);
                }
            }

            @Override
            public void onTransferCompleted(int transId, String fileName, int errorCode) {
                Log.d(TAG, "onTransferComplete,  tr id : " + transId +  " file name : " + fileName + " error code : " + errorCode);
                if (errorCode == 0) {
                    mFileAction.onTransferComplete(fileName);

                } else {
                    mFileAction.onError("Error", errorCode);
                }
            }

            @Override
            public void onTransferRequested(int id, String fileName) {
                Log.d(TAG, "onTransferRequested,  tr id : " + id
                        + " file name : " + fileName);
                if (FTSampleProviderActivity.isUp) {
                    Log.d(TAG, "FTSampleProviderActivity.isUp");
                    mFileAction.onTransferRequested(id, fileName);
                } else {
                    Log.d(TAG, "FTSampleProviderActivity is not up, invoke activity");
                    mContext.startActivity(new Intent()
                            .setClass(mContext, FTSampleProviderActivity.class)
                            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .setAction("incomingFT").putExtra("tx", id)
                            .putExtra("fileName", fileName));
                    int counter = 0;
                    while (counter < 10) {
                        counter ++;
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if (mFileAction != null) {
                            mFileAction.onTransferRequested(id, fileName);
                            break;
                        }
                    }
                }
            }
        };

        SAft SAftPkg = new SAft();
        try {
            SAftPkg.initialize(this);
        } catch (SsdkUnsupportedException e) {
            if (e.getType() == SsdkUnsupportedException.DEVICE_NOT_SUPPORTED) {
                Toast.makeText(getBaseContext(), "Cannot initialize, DEVICE_NOT_SUPPORTED", Toast.LENGTH_SHORT).show();
            } else if (e.getType() == SsdkUnsupportedException.LIBRARY_NOT_INSTALLED) {
                Toast.makeText(getBaseContext(), "Cannot initialize, LIBRARY_NOT_INSTALLED.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getBaseContext(), "Cannot initialize, unknown.", Toast.LENGTH_SHORT).show();
            }

            e.printStackTrace();
            return;
        } catch (Exception e1) {
            Toast.makeText(getBaseContext(), "Cannot initialize, SAFileTransfer.", Toast.LENGTH_SHORT).show();
            e1.printStackTrace();
            return;
        }

        mSAFileTransfer = new SAFileTransfer(FTSampleProviderImpl.this, mCallback);


        SA mAccessory = new SA();
        try {
            mAccessory.initialize(this);
        } catch (SsdkUnsupportedException e) {
            // Error Handling
        } catch (Exception e1) {
            e1.printStackTrace();
			/*
			 * Your application can not use Accessory package of Samsung
			 * Mobile SDK. You application should work smoothly without using
			 * this SDK, or you may want to notify user and close your app
			 * gracefully (release resources, stop Service threads, close UI
			 * thread, etc.)
			 */
            stopSelf();
        }

    }


    protected void onServiceConnectionRequested(SAPeerAgent peerAgent) {
    	/*
    	* The authenticatePeerAgent(peerAgent) API may not be working properly
    	* depending on the firmware version of accessory device.
        * Recommend to upgrade accessory device firmware if possible.
        */

//    	if(authCount%2 == 1)
//    		isAuthentication = false;
//    	else
//    		isAuthentication = true;
//    	authCount++;

        isAuthentication = false;

        if(isAuthentication) {
            Toast.makeText(getBaseContext(), "Authentication On!", Toast.LENGTH_SHORT).show();
            authenticatePeerAgent(peerAgent);
        }
        else {
            Toast.makeText(getBaseContext(), "Authentication Off!", Toast.LENGTH_SHORT).show();
            acceptServiceConnectionRequest(peerAgent);
        }
    }

    protected void onAuthenticationResponse(SAPeerAgent uPeerAgent,
                                            SAAuthenticationToken authToken, int error) {

        if (authToken.getAuthenticationType() == SAAuthenticationToken.AUTHENTICATION_TYPE_CERTIFICATE_X509) {
            mContext = getApplicationContext();
            byte[] myAppKey = getApplicationCertificate(mContext);

            if (authToken.getKey() != null) {
                boolean matched = true;
                if(authToken.getKey().length != myAppKey.length){
                    matched = false;
                }else{
                    for(int i=0; i<authToken.getKey().length; i++){
                        if(authToken.getKey()[i]!=myAppKey[i]){
                            matched = false;
                        }
                    }
                }
                if (matched) {
                    acceptServiceConnectionRequest(uPeerAgent);
                }
            }
        } else if (authToken.getAuthenticationType() == SAAuthenticationToken.AUTHENTICATION_TYPE_NONE)
            Log.e(TAG, "onAuthenticationResponse : CERT_TYPE(NONE)");
    }

    private static byte[] getApplicationCertificate(Context context) {
        if(context == null) {
            return null;
        }
        Signature[] sigs;
        byte[] certificat = null;
        String packageName = context.getPackageName();
        if (context != null) {
            try {
                PackageInfo pkgInfo = null;
                pkgInfo = context.getPackageManager().getPackageInfo(
                        packageName, PackageManager.GET_SIGNATURES);
                if (pkgInfo == null) {
                    return null;
                }
                sigs = pkgInfo.signatures;
                if (sigs == null) {
                } else {
                    CertificateFactory cf = CertificateFactory
                            .getInstance("X.509");
                    ByteArrayInputStream stream = new ByteArrayInputStream(
                            sigs[0].toByteArray());
                    X509Certificate cert;
                    cert = X509Certificate.getInstance(stream);
                    certificat = cert.getPublicKey().getEncoded();
                }
            } catch (NameNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (CertificateException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (javax.security.cert.CertificateException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        return certificat;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "Service Stopped.");
    }

    public void onDataAvailableonChannel(int connectionId, long channelId, String data) {
        Log.i(TAG, " This is response received" + data);
    }

    @Override
    protected void onServiceConnectionResponse(SAPeerAgent peer, SASocket uSocket, int error) {
        Log.i(TAG, "onServiceConnectionResponse: " + error);
        if (error == CONNECTION_SUCCESS) {
            FTSampleProviderConnection localConnection = (FTSampleProviderConnection) uSocket;
            if (uSocket != null) {
                mConnection = localConnection;
                Toast.makeText(getBaseContext(), "Connection established for FT", Toast.LENGTH_SHORT).show();
                // FTSampleProviderConnection myConnection = (HelloAccessoryProviderConnection) thisConnection;

                if (mConnectionsMap == null) {
                    mConnectionsMap = new HashMap<Integer, FTSampleProviderConnection>();
                }

                localConnection.mConnectionId = (int) (System.currentTimeMillis() & 255);

                mConnectionsMap.put(mConnection.mConnectionId, mConnection);
            }
        }
    }

    @Override
    protected void onFindPeerAgentResponse(SAPeerAgent peerAgent, int result) {
    }

    public void registerFileAction(FileAction action){
        this.mFileAction = action;
    }

    public void cancelFileTransfer(int transId) {
        if (mSAFileTransfer != null) {
            mSAFileTransfer.cancel(transId);
        }
    }

    public void receiveFile(int transId, String path, boolean bAccept) {
        Log.d(TAG, "receiving file : transId: " + transId + "bAccept : " + bAccept);
        if (mSAFileTransfer != null) {
            if (bAccept) {
                mSAFileTransfer.receive(transId, path);

            } else {
                mSAFileTransfer.reject(transId);
            }
        }
    }

    public class FTSampleProviderConnection extends SASocket {
        int k=0;
        int l=0;
        public static final String TAG = "FTSampleProviderConnection";
        int mConnectionId;
        MediaPlayer mediaPlayer = new MediaPlayer();
        final AudioManager audioManager = (AudioManager) getApplicationContext().getSystemService(getApplicationContext().AUDIO_SERVICE);
        final String[] bb = getMusic();


        public FTSampleProviderConnection() {

            super(FTSampleProviderConnection.class.getName());
        }

        @Override
        protected void onServiceConnectionLost(int errorCode) {
            Log.e(TAG, "onServiceConectionLost for peer = " + mConnectionId + "error code =" + errorCode);
            mConnection = null;
        }

        @Override
        public void onReceive(int channelId, byte[] data) {


            for(int i=0;i<bb.length;i++){
                if(bb[i]==null || bb[i]=="".toString()){
                    bb[i]="aaa";
                }
            }



            final String strToUpdateUI = new String(data);

            if(Arrays.equals(data, "listemusique".getBytes())){
                final FTSampleProviderConnection uHandler = mConnectionsMap.get(Integer
                        .parseInt(String.valueOf(mConnectionId)));
                if(uHandler == null){
                    return;
                }

                new Thread(new Runnable() {
                    public void run() {
                        try {

                            String[] l=fill(new File("/storage/emulated/0/Music/"));
                            int j= l.length;
                            String e = Integer.toString(j);
                            uHandler.send(HELLOACCESSORY_CHANNEL_ID, ("/storage/emulated/0/Music/"+":").toString().getBytes());
                            for(int i=0; i<l.length;i++){
                                if(l[i]!="".toString() && l[i]!="..".toString() && l[i]!=null) {
                                    if(!(l[i].contains(".jpg"))&&!(l[i].contains(".jpeg"))&&!(l[i].contains(".png"))) {
                                        uHandler.send(HELLOACCESSORY_CHANNEL_ID, (l[i] + ":").toString().getBytes());
                                    }
                                }
                            }

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                }).start();
            }else if(Arrays.equals(data, "listedossiermusique".getBytes())){
                final FTSampleProviderConnection uHandler = mConnectionsMap.get(Integer
                        .parseInt(String.valueOf(mConnectionId)));
                if(uHandler == null){
                    return;}
                new Thread(new Runnable() {
                    public void run() {
                        try {

                            String[] l=fill(new File("/storage/emulated/0/Music/"));
                            int j= l.length;
                            String e = Integer.toString(j);
                            String[] d={};
                            for(int i=0; i<l.length;i++){
                                if((l[i].contains(".mp3"))){
                                    d[i]=l[i];
                                }
                            }
                            for(int i=0;i<d.length;i++){
                                uHandler.send(HELLOACCESSORY_CHANNEL_ID, (l[i]+":").getBytes());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                }).start();
            }
            else if(Arrays.equals(data, "listeimage".getBytes())){
                final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                        .parseInt(String.valueOf(mConnectionId)));
                if(uHandler == null){
                    return;}
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            String[] l=fill(new File("/storage/emulated/0/Pictures/Screenshots/"));
                            int j= l.length;
                            String e = Integer.toString(j);
                            for(int i=0; i<l.length;i++){
                                uHandler.send(HELLOACCESSORY_CHANNEL_ID, (l[i] + ":").getBytes());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                }).start();
            }else{
                String v;
                try {
                    v = new String(data,"UTF-8");
                    Log.e("az", v);
                    if(v.contains("creerdossiermusique")){
                        final String [] a=v.split(":");
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}
                        new Thread(new Runnable() {
                            public void run() {

                                try {
                                    File folder= new File("/storage/emulated/0/Music/"+a[1]+"/");
                                    folder.mkdirs();
                                    if (!folder.exists()) {
                                        if (!folder.mkdirs()) {
                                            Log.e("TravellerLog :: ", "Problem creating Image folder");
                                        } else {
                                        }
                                    }
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, "Dossier creer".getBytes());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                        }).start();
                    }else if(v.contains("creerInternedossiermusique")){
                        int i=0;
                        final String [] a=v.split(":");
                        for(i=0;i<a.length;i++){
                            Log.d("azed",a[i]);
                        }
                        Log.d("azea",a[1]+"/"+a[2]+"/");
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}
                        new Thread(new Runnable() {
                            public void run() {

                                try {

                                    File folder= new File(a[1]+"/"+a[2]+"/");
                                    folder.mkdir();
                                    if (!folder.exists()) {
                                        if (!folder.mkdirs()) {
                                            Log.e("TravellerLog :: ", "Problem creating Image folder");
                                        }else{

                                        }
                                    }else{

                                    }
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, "Dossier creerqssssssqsqsq".getBytes());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                        }).start();
                    }
                    //waliiiiid
                    else if(v.contains("getTitre")){
                        System.out.println("Tiiiiiiiiiiiiiiiiiittttttttttttt");

                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}

                        new Thread(new Runnable() {
                            public void run() {

                                try {
                                    if(FTSampleProviderActivity.titre=="-"){
                                        uHandler.send(HELLOACCESSORY_CHANNEL_ID, ("Music not found").getBytes());
                                    }else {


                                        uHandler.send(HELLOACCESSORY_CHANNEL_ID, (FTSampleProviderActivity.titre+" - "+FTSampleProviderActivity.artiste).getBytes());}
                                } catch (Exception e) {
                                }
                            }
                        }).start();

                    }
                    //waliiiiid
                    else if(v.contains("creerdossierimage")){
                        final String [] a=v.split(":");
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}
                        new Thread(new Runnable() {
                            public void run() {

                                try {
                                    File folder= new File("/storage/emulated/0/Pictures/Screenshots/"+a[1]+"/");
                                    folder.mkdirs();
                                    if (!folder.exists()) {
                                        if (!folder.mkdirs()) {
                                            Log.e("TravellerLog :: ", "Problem creating Image folder");
                                            uHandler.send(HELLOACCESSORY_CHANNEL_ID, "Probleme de creation".getBytes());
                                        }else{
                                            uHandler.send(HELLOACCESSORY_CHANNEL_ID, "Dossier creer".getBytes());
                                        }
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                        }).start();
                    }else if(v.contains("deplacermusiqueficherint")){
                        int i = 0;
                        final String[] a = v.split(":");

                        Log.d(" qsdazaaqsd", a[3] + "  " + "hathi hia l fichier");
                        Log.d(" qsdazaa", a[1] + a[3] + "  " + a[2]);
                        //final String [] b = a[3].split(",".trim());
                        Log.d("Other Exceptionazzzzzzzzazazazazza", a[2].toString());
                        final FTSampleProviderConnection uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if (uHandler == null) {
                            return;
                        }
                        new Thread(new Runnable() {
                            public void run() {

                                try {
                                    moveFile(a[1], a[3], a[2]);
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, "fichier demplacer".getBytes());
                                } catch (Exception e) {
                                    // TODO: handle exception
                                }
                            }

                        }).start();

                    }else if(v.contains("deplacfichermusiquetomusic")){
                        int i = 0;
                        final String[] a = v.split(":");
                        for (i = 0; i < a.length; i++) {
                            Log.d("aa ", a[i] + "  " + i);
                        }
                        Log.d(" qsdazaaqsd", a[3] + "  " + "hathi hia l fichier");
                        Log.d(" qsdazaa", a[1] + a[3] + "  " + a[2]);
                        //final String [] b = a[3].split(",".trim());
                        Log.d("Other Exceptionazzzzzzzzazazazazza", a[2].toString());
                        final FTSampleProviderConnection uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if (uHandler == null) {
                            return;
                        }
                        new Thread(new Runnable() {
                            public void run() {

                                try {
                                    moveFile(a[1], a[3], a[2]);
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, "fichier demplacer".getBytes());
                                } catch (Exception e) {
                                    // TODO: handle exception
                                }
                            }

                        }).start();

                    }else if(v.contains("playmusic")){
                        final String[] a = v.split(":");
                        String PATH_TO_FILE = a[1]+a[2];
                        for (int i = 0; i < a.length; i++) {
                            Log.d("aaa  ", a[i] + "  " + i);
                        }
                        try {
                            mediaPlayer.setDataSource(PATH_TO_FILE);
                        } catch ( Exception e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        try {
                            mediaPlayer.prepare();
                        } catch ( Exception e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        mediaPlayer.start();

                    }else if(v.contains("playlistmusic")){
                        try {
                            mediaPlayer.setDataSource(bb[0]);
                        } catch ( Exception e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        try {
                            mediaPlayer.prepare();
                        } catch ( Exception e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        mediaPlayer.start();
                        final FTSampleProviderConnection uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if (uHandler == null) {
                            return;
                        }
                        new Thread(new Runnable() {
                            public void run() {
                                try {
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, bb[0].getBytes());
                                } catch (Exception e) {

                                }
                            }

                        }).start();
                    }else if(v.contains("pauselist")){
                        mediaPlayer.pause();

                    }else if(v.contains("listreplia")){
                        mediaPlayer.start();

                    }else if(v.contains("prevsong")){
                        if(k>0){
                            mediaPlayer.stop();
                            mediaPlayer.reset();
                            k--;

                            try {
                                mediaPlayer.setDataSource(bb[k]);
                            } catch ( Exception e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                            try {
                                mediaPlayer.prepare();
                            } catch ( Exception e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                            mediaPlayer.start();
                            final FTSampleProviderConnection uHandler = mConnectionsMap.get(Integer
                                    .parseInt(String.valueOf(mConnectionId)));
                            if (uHandler == null) {
                                return;
                            }
                            new Thread(new Runnable() {
                                public void run() {

                                    try {

                                        uHandler.send(HELLOACCESSORY_CHANNEL_ID, bb[k].getBytes());
                                    } catch (Exception e) {

                                    }
                                }

                            }).start();
                        }else{

                        }

                    }else if(v.contains("nextsong")){
                        if(k<bb.length && bb[k]!="aaa".toString() ){
                            mediaPlayer.stop();
                            mediaPlayer.reset();
                            k++;

                            try {
                                mediaPlayer.setDataSource(bb[k]);
                            } catch ( Exception e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                            try {
                                mediaPlayer.prepare();
                            } catch ( Exception e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                            mediaPlayer.start();
                            final FTSampleProviderConnection uHandler = mConnectionsMap.get(Integer
                                    .parseInt(String.valueOf(mConnectionId)));
                            if (uHandler == null) {
                                return;
                            }
                            new Thread(new Runnable() {
                                public void run() {

                                    try {

                                        uHandler.send(HELLOACCESSORY_CHANNEL_ID, bb[k].getBytes());
                                    } catch (Exception e) {

                                    }
                                }

                            }).start();
                        }else{
                            k=0;
                            mediaPlayer.stop();
                            mediaPlayer.reset();
                            k++;
                            try {
                                mediaPlayer.setDataSource(bb[k]);
                            } catch ( Exception e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                            try {
                                mediaPlayer.prepare();
                            } catch ( Exception e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                            mediaPlayer.start();
                            final FTSampleProviderConnection uHandler = mConnectionsMap.get(Integer
                                    .parseInt(String.valueOf(mConnectionId)));
                            if (uHandler == null) {
                                return;
                            }
                            new Thread(new Runnable() {
                                public void run() {

                                    try {

                                        uHandler.send(HELLOACCESSORY_CHANNEL_ID, bb[0].getBytes());
                                    } catch (Exception e) {

                                    }
                                }

                            }).start();
                        }

                    }else if(v.contains("pausemusic")){
                        final String[] a = v.split(":");
                        mediaPlayer.pause();

                    }else if(v.contains("stopmusic")){
                        final String[] a = v.split(":");
                        mediaPlayer.stop();
                        mediaPlayer.reset();

                    }else if(v.contains("volumeplus")){
                        final String[] a = v.split(":");
                        audioManager.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_PLAY_SOUND);

                    }else if(v.contains("moinsvolume")){
                        final String[] a = v.split(":");
                        audioManager.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_PLAY_SOUND);

                    }else if(v.contains("deplacerfichermusique")) {
                        int i = 0;
                        final String[] a = v.split(":");
                        for (i = 0; i < a.length; i++) {
                            Log.d("aa  ", a[i] + "  " + i);
                            mediaPlayer.stop();
                            mediaPlayer.reset();
                        }
                        //Log.d(" qsdazaaqsd", a[3] + "  " + "hathi hia l fichier");
                        //  Log.d(" qsdazaa", a[1] + a[4] + "  " + a[1] + a[2] + "/");
                        //final String [] b = a[3].split(",".trim());
                        Log.d("Other Exceptionazzzzzzzzazazazazza", a[2].toString());
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}
                        new Thread(new Runnable() {
                            public void run() {

                                try {

                                    moveFile(a[1], a[3],  a[2] + "/");
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, "fichier demplacer".getBytes());
                                } catch (Exception e) {
                                    // TODO: handle exception
                                }
                            }

                        }).start();
                    }else if(v.contains("deplacerdossiermusique")){
                        int i = 0;
                        final String [] a=v.split(":");
                        final String [] b = a[3].split(",".trim());
                        Log.d("Other Exceptionazzzzzzzzazazazazza",a[2].toString());
                        for (i = 0; i < a.length; i++) {
                            Log.d("aa  ", a[i] + "  " + i);
                        }
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}
                        new Thread(new Runnable() {
                            public void run() {

                                try {

                                    copyDirectoryOneLocationToAnotherLocation(new File(a[1]+a[3]+"/"), new File(a[2]+"/"+a[3]+"/"));
                                    /*File folder = new File(a[1]);
                                    String fileName = folder.getPath()+ "/"+a[3];
                                    Log.d("alouu" ,fileName);
                                    File myFile = new File(fileName);
                                    if(myFile.exists()){
                                        myFile.delete();
                                    }*/
                                    String fileName = a[1]+a[3];
                                    Log.d("alouu" ,fileName);
                                    File myFile = new File(fileName);
                                    /*if (myFile.isDirectory()) {
                                        String[] children = myFile.list();
                                        for (int i = 0; i < children.length; i++) {
                                            new File(myFile, children[i]).delete();
                                        }
                                    }*/
                                    DeleteRecursive(myFile);
                                    //uHandler.send(HELLOACCESSORY_CHANNEL_ID, "fichier demplacer".getBytes());
                                    final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                            .parseInt(String.valueOf(mConnectionId)));
                                    if(uHandler == null){
                                        return;}
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, "Dossier demplacer".getBytes());
                                } catch (Exception e) {
                                    // TODO: handle exception
                                }
                            }

                        }).start();

                    }else if(v.contains("deplacerinterdossiermusique")){
                        int i = 0;
                        final String [] a=v.split(":");
                        final String [] b = a[3].split(",".trim());
                        Log.d("Other Exceptionazzzzzzzzazazazazza",a[2].toString());
                        for (i = 0; i < a.length; i++) {
                            Log.d("aa  ", a[i] + "  " + i);
                        }
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}
                        new Thread(new Runnable() {
                            public void run() {

                                try {

                                    copyDirectoryOneLocationToAnotherLocation(new File(a[1]+a[3]+"/"), new File(a[2]+"/"+a[3]+"/"));
                                    /*File folder = new File(a[1]);
                                    String fileName = folder.getPath()+ "/"+a[3];
                                    Log.d("alouu" ,fileName);
                                    File myFile = new File(fileName);
                                    if(myFile.exists()){
                                        myFile.delete();
                                    }*/
                                    String fileName = a[1]+a[3];
                                    Log.d("alouu" ,fileName);
                                    File myFile = new File(fileName);
                                    /*if (myFile.isDirectory()) {
                                        String[] children = myFile.list();
                                        for (int i = 0; i < children.length; i++) {
                                            new File(myFile, children[i]).delete();
                                        }
                                    }*/
                                    DeleteRecursive(myFile);
                                    //uHandler.send(HELLOACCESSORY_CHANNEL_ID, "fichier demplacer".getBytes());
                                    final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                            .parseInt(String.valueOf(mConnectionId)));
                                    if(uHandler == null){
                                        return;}
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, "Dossier demplacer".getBytes());
                                } catch (Exception e) {
                                    // TODO: handle exception
                                }
                            }

                        }).start();

                    }else if(v.contains("deplacermusicdossiertomusic")){
                        int i = 0;
                        final String [] a=v.split(":");
                        final String [] b = a[3].split(",".trim());
                        Log.d("Other Exceptionazzzzzzzzazazazazza",a[2].toString());
                        for (i = 0; i < a.length; i++) {
                            Log.d("aa  ", a[i] + "  " + i);

                        }
                        copyDirectoryOneLocationToAnotherLocation(new File(a[1]+a[3]+"/"), new File(a[2]+a[3]+"/"));

                        String fileName = a[1]+a[3];
                        Log.d("alouu" ,fileName);
                        File myFile = new File(fileName);

                        DeleteRecursive(myFile);
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}
                        new Thread(new Runnable() {
                            public void run() {

                                try {

                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, "fichier demplacer".getBytes());
                                } catch (Exception e) {
                                    // TODO: handle exception
                                }
                            }

                        }).start();

                    }else if(v.contains("deplacerficherimage")){

                        final String [] a=v.split(":");
                        final String [] b = a[2].split(",".trim());
                        Log.d("Other Exceptionazzzzzzzzazazazazza", a[2].toString());
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}
                        new Thread(new Runnable() {
                            public void run() {

                                try {
                                    moveFile("/storage/emulated/0/Pictures/Screenshots/", a[1], "/storage/emulated/0/Pictures/Screenshots/"+b[1]+"/");
                                    //uHandler.send(HELLOACCESSORY_CHANNEL_ID, "fichier demplacer".getBytes());
                                } catch (Exception e) {
                                    // TODO: handle exception
                                }
                            }

                        }).start();
                    }else if(v.contains(".jpg") || v.contains(".png")){

                    }else if(v.contains("listerundossiermusicale")){
                        final String [] a=v.split(":");
                        Log.e("Other Exceptionazzzzzzzzazazazazza","myTag :"+a[1].toString());
                        final FTSampleProviderConnection  uHandler = mConnectionsMap.get(Integer
                                .parseInt(String.valueOf(mConnectionId)));
                        if(uHandler == null){
                            return;}

                        //final String b = searchFile(a[1]);
                        new Thread(new Runnable() {
                            public void run() {

                                try {

                                    String[] l=fill(new File(a[1].toString()));
                                    int j= l.length;
                                    for(int i=0;i<j;i++) {
                                        Log.d("aze", " " + l[i]);
                                    }
                                    String e = Integer.toString(j);
                                    uHandler.send(HELLOACCESSORY_CHANNEL_ID, (a[1]+":").toString().getBytes());
                                    for(int i=0; i<l.length;i++){
                                        if(l[i]!="".toString() && l[i]!="..".toString() && l[i]!=null) {
                                            if((!l[i].contains(".jpg"))&&(!l[i].contains(".jpeg"))&&(!l[i].contains(".png"))) {
                                                uHandler.send(HELLOACCESSORY_CHANNEL_ID, (l[i] + ":").toString().getBytes());
                                            }
                                        }
                                    }


                                    //uHandler.send(HELLOACCESSORY_CHANNEL_ID, strToUpdateUI.getBytes());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                        }).start();
                    }else{

                    }
                } catch (UnsupportedEncodingException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

        }


        @Override
        public void onError(int channelId, String errorMessage, int errorCode) {
            mFileAction.onError(errorMessage, errorCode);
            Log.e(TAG, "Connection is not alive ERROR: " + errorMessage + "  " + errorCode);
        }
    }

    public interface FileAction {
        void onError(String errorMsg, int errorCode);
        void onProgress(long progress);
        void onTransferComplete(String path);
        void onTransferRequested(int id, String path);
    }

    public String[] fill(File f)
    {
        File[]dirs = f.listFiles();
        //this.setTitle("Current Dir: "+f.getName());
        List<Option>dir = new ArrayList<Option>();
        List<Option>fls = new ArrayList<Option>();
        try{
            for(File ff: dirs)
            {
                if(ff.isDirectory())
                    dir.add(new Option(ff.getName(),"Folder",ff.getAbsolutePath()));
                else
                {
                    fls.add(new Option(ff.getName(),"File Size: "+ff.length(),ff.getAbsolutePath()));
                }
            }
        }catch(Exception e)
        {

        }
        Collections.sort(dir);
        Collections.sort(fls);
        dir.addAll(fls);
        if(!f.getName().equalsIgnoreCase("sdcard")){
            dir.add(0,new Option("..","Parent Directory",f.getParent()));
        }
        String[] l =new String[100];
        for(int i =0 ; i<dir.size();i++){
            l[i]=dir.get(i).getName();
        }
        return l;
    }
    public void createFolder(String path){
        File folder= new File(path);
        folder.mkdirs();
        if (!folder.exists()) {
            if (!folder.mkdirs()) {
                Log.e("TravellerLog :: ", "Problem creating Image folder");
            }
        }
    }
    private void moveFile(String inputPath, String inputFile, String outputPath) {

        InputStream in = null;
        OutputStream out = null;
        try {

            //create output directory if it doesn't exist
            File dir = new File (outputPath);
            if (!dir.exists())
            {
                dir.mkdirs();
            }


            in = new FileInputStream(inputPath + inputFile);
            out = new FileOutputStream(outputPath + inputFile);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            in = null;

            // write the output file
            out.flush();
            out.close();
            out = null;

            // delete the original file
            new File(inputPath + inputFile).delete();


        }

        catch (FileNotFoundException fnfe1) {
            Log.e("tag", fnfe1.getMessage());
        }
        catch (Exception e) {
            Log.e("tag", e.getMessage());
        }

    }
    private String searchFile(String text) {
        String result = "";
        File[] files = new File("/").listFiles();
        for (File f : files) {
            if(f.getName().indexOf(text)>=0){
                result += f.getPath() + "\n";
            }
        }
        if (result.equals("")) {
            result = "null";
        }
        return result;
    }

    public  void copyDirectoryOneLocationToAnotherLocation(File sourceLocation, File targetLocation)
            throws IOException {

        if (sourceLocation.isDirectory()) {
            if (!targetLocation.exists()) {
                targetLocation.mkdir();
            }

            String[] children = sourceLocation.list();
            for (int i = 0; i < sourceLocation.listFiles().length; i++) {

                copyDirectoryOneLocationToAnotherLocation(new File(sourceLocation, children[i]),
                        new File(targetLocation, children[i]));
            }
        } else {

            InputStream in = new FileInputStream(sourceLocation);

            OutputStream out = new FileOutputStream(targetLocation);

            // Copy the bits from instream to outstream
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        }

    }
    void DeleteRecursive(File fileOrDirectory) {

        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                DeleteRecursive(child);

        fileOrDirectory.delete();

    }

    private String[] getMusic() {
        final Cursor mCursor = getApplicationContext().getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[] { MediaStore.Audio.Media.DATA }, null, null,
                "LOWER(" + MediaStore.Audio.Media.TITLE + ") ASC");

        int count = mCursor.getCount();

        String[] songs = new String[count];
        int i = 0;
        if (mCursor.moveToFirst()) {
            do {
                if(mCursor.getString(0).contains(".mp3")){
                    songs[i] = mCursor.getString(0);
                    i++;
                }
            } while (mCursor.moveToNext());
        }

        mCursor.close();

        return songs;
    }
    private List<String> getTitleMusic() {
        final Cursor mCursor = getApplicationContext().getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[] { MediaStore.Audio.Media.TITLE }, null, null,
                "LOWER(" + MediaStore.Audio.Media.DATA + ") ASC");

        int count = mCursor.getCount();

        List<String> arrlist = new ArrayList<String>(count);
        int i = 0;
        if (mCursor.moveToFirst()) {
            do {
                if(mCursor.getString(0).contains(".mp3")){
                    arrlist.add(mCursor.getString(0));
                    i++;
                }
            } while (mCursor.moveToNext());
        }

        mCursor.close();

        return arrlist;
    }
}
