package com.samsung.accessory.FTSampleProvider.entities;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by BayaWalid on 17/03/15.
 */
@DatabaseTable(tableName="Chanson")
public class Chanson {

    @DatabaseField(generatedId=true)
    private int id;
    @DatabaseField
    private String titre;
    @DatabaseField
    private String artiste;
    @DatabaseField
    private String album;

    public Chanson(){}

    public Chanson(String titre, String artiste, String album){
        this.setTitre(titre);
        this.setArtiste(artiste);
        this.setAlbum(album);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitre(){
        return titre;
    }
    public void setTitre(String titre){
        this.titre=titre;
    }

    public String getArtiste(){
        return artiste;
    }
    public void setArtiste(String artiste){
        this.artiste=artiste;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    @Override
    public String toString() {
        return ""+getTitre()+" "+getArtiste()+" "+getAlbum();
    }
}
