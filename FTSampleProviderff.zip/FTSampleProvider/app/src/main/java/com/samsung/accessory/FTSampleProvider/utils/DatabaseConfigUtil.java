package com.samsung.accessory.FTSampleProvider.utils;


import com.j256.ormlite.android.apptools.OrmLiteConfigUtil;
import com.samsung.accessory.FTSampleProvider.entities.Chanson;

import java.io.IOException;
import java.sql.SQLException;

public class DatabaseConfigUtil extends OrmLiteConfigUtil{

	final static Class<?>[] classes =new Class[]{Chanson.class};
	
	public static void main(String[] args) throws SQLException, IOException {
		writeConfigFile("db_conf.txt",classes);
	}

}
