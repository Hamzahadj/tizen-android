package com.samsung.accessory.FTSampleProvider.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.samsung.accessory.FTSampleProvider.R;
import com.samsung.accessory.FTSampleProvider.entities.Chanson;

import java.util.List;




    public class ListAdapter extends BaseAdapter {

        private Context mContext;
        private final List<Chanson> web;

        public ListAdapter(Context c, List<Chanson> web) {
            mContext = c;

            this.web = web;
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return web.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return null;
        }
    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            View grid;
            LayoutInflater inflater = (LayoutInflater) mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            if (convertView == null) {
                grid = new View(mContext);
                grid = inflater.inflate(R.layout.grid_single, null);
                TextView textView = (TextView) grid.findViewById(R.id.grid_text);

                textView.setText(web.get(position).getTitre()+" - "+web.get(position).getArtiste());

            } else {
                grid = (View) convertView;
            }
            return grid;
        }
}
