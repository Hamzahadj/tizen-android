
var SAAgent = null;
var SASocket = null;
var CHANNELID = 107;
var ldm =[];
var ldi=[];
var a;
var b;
var currentpath;
var firstpath;
var currentpatha;
var currentpathDepCop;
var fichieradeplacer;
var paths =[];
var pathsCopMove =[];
var indexpath=0;
var indexpathDepCop=0;
var currentlocation;
var dossierCourant="";
var ProviderAppName1 = "FTSampleProvider";
var currentdate = new Date(); 
var searchIDsInt=[];
var DossNavigated=[];
var totale;
var DossenNav=0;
var pathinitiale;
var i=1;
var j=1;
//var play="p";
var pathNav="/storage/emulated/0/Music/"; 
var datetime =  currentdate.getDate() +"_"
                + (currentdate.getMonth()+1)+"_" 
                + currentdate.getFullYear() +"_"  
                + currentdate.getHours() + ";"  
                + currentdate.getMinutes() +";" 
                + currentdate.getSeconds()+"_";

function createHTML(log_string)
{
	//window.location.href="listeMusique.html";
	var log = document.getElementById('resultBoard');
	log.innerHTML = log.innerHTML + "<br>" + log_string;
}
function onerror(err) {
	console.log("err [" + err + "]");
}
var agentCallback = {
	onconnect : function(socket) {
		SASocket = socket;
		//alert("HelloAccessory Connection established with RemotePeer");
		//createHTML("startConnection");
		SASocket.setSocketStatusListener(function(reason){
			console.log("Service connection lost, Reason : [" + reason + "]");
			disconnect();
		});
	},
	onerror : onerror
};
var peerAgentFindCallback = {
	onpeeragentfound : function(peerAgent) {
		try {
			if (peerAgent.appName == ProviderAppName1) {
				SAAgent.setServiceConnectionListener(agentCallback);
				SAAgent.requestServiceConnection(peerAgent);
			} else {
				alert("Not expected app!! : " + peerAgent.appName);
			}
		} catch(err) {
			console.log("exception [" + err.name + "] msg[" + err.message + "]");
		}
	},
	onerror : onerror
}
function onsuccess(agents) {
	try {
		if (agents.length > 0) {
			SAAgent = agents[0];
			
			SAAgent.setPeerAgentFindListener(peerAgentFindCallback);
			SAAgent.findPeerAgents();
		} else {
			alert("Not found SAAgent!!");
		}
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function connect() {
	if (SASocket) {
		//alert('Already connected!');
        return false;
    }
	try {
		webapis.sa.requestSAAgent(onsuccess, function (err) {
			console.log("err [" + err.name + "] msg[" + err.message + "]");
		});
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function disconnect() {
	try {
		if (SASocket != null) {
			SASocket.close();
			SASocket = null;
			createHTML("closeConnection");
		}
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function onreceiveCdossierMusique(channelId,data){
	alert("Folder created ");
}
function onreceiveplayMusique(channelId,data){}
function onreceiveplaylistMusique(channelId,data){
	//alert(data);
v = new String(data);
a = v.split("/");
document.getElementById('location').innerHTML=a[a.length-1];
}
function onreceivenextMusique(channelId,data){
	//alert(data);
v = new String(data);
a = v.split("/");
document.getElementById('location').innerHTML=a[a.length-1];
}
function onreceiveprevMusique(channelId,data){
	//alert(data);
v = new String(data);
a = v.split("/");
document.getElementById('location').innerHTML=a[a.length-1];
}
function onreceivestoplistMusique(channelId,data){alert(data);}
function onreceiveCdossierMusiqueI(channelId,data){
	alert("Folder created");
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 $("#ActionDossierMusique").remove();
	 //$("#resultboard").remove();
	 sendListeMusique();
	 document.getElementById('location').innerHTML="Music";
}
function onreceivelistedossiermusicale(){
	v = new String(data);
	var aa = v.split(":");
	var i;
	var j;
	var ldmm;
	for( i=0; i<aa.length;i++){
		if(aa[i]== "null"){
			aa.	array.splice(i, 1);
			console.log(a);
		}
	}
	var x=0;
	for(j=0; j<aa.length;j++){
		if(aa[j].indexOf("mp3")==-1){
		 ldmm.push(aa[j]+":");
		 //x++; 
		}
	}
	
	for(j=0; j<aa.length;j++){
		console.log(ldm[j]);
	}
	//currentpath=aa[0];
	
	//console.log(currentpath);
	$("#content").append("<div id='resultboard' style=' font-weight: normal;'><div id='resultD'></div><div id='resultM'></div><div>")
	for(i=0;i<aa.length;i++){
		//$("#resultBoard").append("<li>"+a[i]+"</li>");
		if(aa[i].indexOf("/")==-1 && aa[i]!="" && aa[j]!=".." && aa[j].indexOf(".amr")==-1 && aa[j].indexOf(".jpg")==-1 && aa[j].indexOf(".png")==-1){
		if(aa[i].indexOf("mp3")==-1){
			//console.log(ldm);
			
			  $("#resultD").append("<li onclick='actionDossierMusique(\""+aa[i]+"\");'><button class='btn3'>"+aa[i]+"</button></li><br/>");
			 
			  
		}else{
			//console.log(ldm);
			
			 $("#resultM").append("<li onclick='actionchansanMusique(\""+aa[i]+"\",\""+ldmm+"\");'><button class='btn4'>"+aa[i]+"<button></li><br/>");
		}
		}
	}
}
function onreceiveListeMusique(channelId, data) {
	document.getElementById('location').innerHTML="Music";
	console.log(currentpath);
	console.log(dossierCourant);
	//ldm=[];
	$("#Move").show();
	currentlocation="listemusique";
	v = new String(data);
	 a = v.split(":");
	var i;
	var j;
	for( i=0; i<a.length;i++){
		if(a[i]== "null"){
			a.	array.splice(i, 1);
			console.log(a);
		}
	}
	var x=0;
	for(j=0; j<a.length;j++){
		if(a[j].indexOf(".mp3")==-1 && a[j].indexOf("/")==-1 && a[j]!=".." && a[j].indexOf(".amr")==-1 && a[j].indexOf(".jpg")==-1 && a[j].indexOf(".png")==-1){
		 ldm.push(a[j]);
		 //x++; 
		}
		//console.log(ldm);
	}
	$("#content").append("<div id='resultboard' style=' font-weight: normal;'><div><ul id='resultD'><ul></div><div><ul id='resultM'></ul></div><div>");
	//$("#content").append("<button id='az' onclick='back();'>back</button>");

	for(i=0;i<a.length;i++){
		//$("#resultBoard").append("<li>"+a[i]+"</li>");
		if(a[i].indexOf("/")==-1){
			if((a[i]!="") && (a[i]!="..") && (a[i].indexOf(".amr")==-1)){
				
		if(a[i].indexOf(".mp3")==-1){
			//console.log(ldm);
			
			  $("#resultD").append("<li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='actionDossierMusique(\""+a[i]+"\",\""+ldm+"\");'><h1 style='color: white;'><img src='./images/Open_Folder.jpga359780b-fe23-4fbb-86ae-6ec47653a3ddLarger.jpg' style='width: 10%;height: 10%;'/>"+"   "+a[i]+"</h1></li><br/>");
			//$("#resultD").append("<li ><input class='chekbox' type='checkbox' name='doss' value="+a[i]+" onchange='valueChanged();'>"+a[i]+"</input></li>");		
	
			  
		}else{
			
			//console.log(ldm);
			//console.log(ldm);
			//$("#resultM").append("<li ><input class='chekbox' type='checkbox' name='doss' value="+a[i]+" onchange='valueChanged();'>"+a[i]+"</input></li>");	
			 $("#resultM").append("<li  style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='actionchansanMusique(\""+a[i]+"\",\""+ldm+"\");'><h1 style='color: white;'><img src='./images/Farm-Fresh_music.png' style='width: 10%;height: 10%;'/>"+"   "+a[i]+"</h1></li><br/>");
		
			}
			}
		}else{
			currentpath=a[i];
			paths.push(currentpath);
			indexpath++;
			//console.log(indexpath);
			//console.log(paths[0]);
			//console.log(dossierCourant);
			
		}
		
	}
	
}
function onreceiveListeMusiqueaa(channelId, data) {
	console.log(data);
	console.log(currentpath);
	console.log(dossierCourant);
	console.log(currentlocation);
	//ldm=[];
	$("#Move").show();
	currentlocation="listemusiqueaa";
	v = new String(data);
	 a = v.split(":");
	var i;
	var j;
	for( i=0; i<a.length;i++){
		if(a[i]== "null"){
			a.	array.splice(i, 1);
			console.log(a);
		}
	}
	var x=0;
	for(j=0; j<a.length;j++){
		if(a[j].indexOf(".mp3")==-1 && a[j].indexOf("/")==-1 && a[j]!=".." && a[j].indexOf(".amr")==-1 && a[j].indexOf(".jpg")==-1 && a[j].indexOf(".png")==-1){
		 ldm.push(a[j]);
		 //x++; 
		}
		//console.log(ldm);
	}
	$("#content").append("<div id='resultboard' style=' font-weight: normal;'><div><ul id='resultD'><ul></div><div><ul id='resultM'></ul></div><div>");
	//$("#content").append("<button id='az' onclick='back();'>back</button>");

	for(i=0;i<a.length;i++){
		//$("#resultBoard").append("<li>"+a[i]+"</li>");
		if(a[i].indexOf("/")==-1){
			if(a[i]!="" && a[i]!=".." && a[i].indexOf(".amr")==-1){
		if(a[i].indexOf(".mp3")==-1){
			//console.log(ldm);
			
			  $("#resultD").append("<li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='actionDossierMusique(\""+a[i]+"\",\""+ldm+"\");'><h1 style='color: white;'><img src='./images/Open_Folder.jpga359780b-fe23-4fbb-86ae-6ec47653a3ddLarger.jpg' style='width: 10%;height: 10%;'/>"+"   "+a[i]+"</h1></li><br/>");
			//$("#resultD").append("<li ><input class='chekbox' type='checkbox' name='doss' value="+a[i]+" onchange='valueChanged();'>"+a[i]+"</input></li>");		
	
			  
		}else{
			//console.log(ldm);
			//console.log(ldm);
			//$("#resultM").append("<li ><input class='chekbox' type='checkbox' name='doss' value="+a[i]+" onchange='valueChanged();'>"+a[i]+"</input></li>");	
			 $("#resultM").append("<li  style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='actionchansanMusique(\""+a[i]+"\",\""+ldm+"\");'><h1 style='color: white;'><img src='./images/Farm-Fresh_music.png' style='width: 10%;height: 10%;'/>"+"   "+a[i]+"</h1></li><br/>");
		}
			}
		}else{
			currentpath=a[i];
			paths.push(currentpath);
			indexpath++;
			//console.log(indexpath);
			//console.log(paths[0]);
			//console.log(dossierCourant);
			
		}
		
	}
	
	
}
function onreceiveListeDesDossierMusique(channelId, data) {
	console.log(data);
	 $("#resultDMBoard").remove();
	 //console.log(pathNav);
	 //console.log(searchIDs);
	//ldm=[];
	currentlocation="listeDossierMusqiue";
	 console.log(currentlocation);
	v = new String(data);
	//console.log(v);
	 a = v.split(":");
	var i;
	var j;
/*	for( i=0; i<a.length;i++){
		if(a[i]== "null"){
			a.	array.splice(i, 1);
			console.log(a);
		}
	}*/
	var x=0;
	for(j=0; j<a.length;j++){
		if(a[j].indexOf(".mp3")==-1 && a[j]!=""){
		 ldm.push(a[j]);
		 
		}
	}
	console.log(ldm);
	console.log(ldm.length);
	 $("#content").append("<div id='resultDMBoard'></div>")
	 $("#resultDMBoard").append("<ul id='liste'></ul>");
	//$("#content").append("<div id='resultboard' style=' font-weight: normal;'><div><ul id='resultD'><ul></div><div>");
	for(i=0;i<ldm.length;i++){
		//$("#resultBoard").append("<li>"+a[i]+"</li>");
		if(ldm[i].indexOf("/")==-1 ){
			
		   console.log(currentpath);
			console.log(ldm[i]);
			console.log(i);
			  //$("#resultD").append("<li onclick='actionDossierMusique(\""+a[i]+"\",\""+ldm+"\");'><input type='checkbox' name='doss' value="+a[i]+">"+a[i]+"</input></li><br/>");
			//$("#resultD").append("<li style= 'border-bottom:  3px solid white; border-width: 120%'><button onclick='sendMovefileMusiqueInt(\""+pathNav+"\",\""+ldm[i]+"\")' style='width:60%; height:40%;background-color: Transparent;background-repeat:no-repeat; font-size: 30px;'>"+ldm[i]+"</button><button style='width:20%;height:60%; margin-left: 90%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>OU</button></li>");		
			 $("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%;' ><button onclick='sendMovefileMusiqueInt(\""+pathNav+"\",\""+ldm[i]+"\")' style='width:60%; height:40%;background-color: Transparent;background-repeat:no-repeat; font-size: 30px;'>"+ldm[i]+"</button><button style='width:30%;height:50%; margin-left: 68%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>open</button></li>");
			
		}else{
			currentpath=ldm[0];
			paths.push(currentpath);
			indexpath++;
			console.log(indexpath);
			console.log(paths[0]);
			console.log(dossierCourant);	
		}
	}
}
function onreceiveListeDesDossierMusique1(channelId, data) {
	console.log(data);
	 $("#resultDMBoard").remove();
	 //console.log(pathNav);
	 //console.log(searchIDs);
	//ldm=[];
	currentlocation="listeDossierMusqiue";
	 console.log(currentlocation);
	v = new String(data);
	//console.log(v);
	 a = v.split(":");
	var i;
	var j;
/*	for( i=0; i<a.length;i++){
		if(a[i]== "null"){
			a.	array.splice(i, 1);
			console.log(a);
		}
	}*/
	var x=0;
	for(j=0; j<a.length;j++){
		if(a[j].indexOf(".mp3")==-1 && a[j]!=""){
		 ldm.push(a[j]);
		 
		}
	}
	console.log(ldm);
	console.log(ldm.length);
	 $("#content").append("<div id='resultDMBoard'></div>")
	 $("#resultDMBoard").append("<ul id='liste'></ul>");
	//$("#content").append("<div id='resultboard' style=' font-weight: normal;'><div><ul id='resultD'><ul></div><div>");
	for(i=0;i<ldm.length;i++){
		//$("#resultBoard").append("<li>"+a[i]+"</li>");
		if(ldm[i].indexOf("/")==-1 ){
			
		   console.log(currentpath);
			console.log(ldm[i]);
			console.log(i);
			  //$("#resultD").append("<li onclick='actionDossierMusique(\""+a[i]+"\",\""+ldm+"\");'><input type='checkbox' name='doss' value="+a[i]+">"+a[i]+"</input></li><br/>");
			//$("#resultD").append("<li style= 'border-bottom:  3px solid white; border-width: 120%'><button onclick='sendMovefileMusiqueInt(\""+pathNav+"\",\""+ldm[i]+"\")' style='width:60%; height:40%;background-color: Transparent;background-repeat:no-repeat; font-size: 30px;'>"+ldm[i]+"</button><button style='width:20%;height:60%; margin-left: 90%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>OU</button></li>");		
			 $("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%;' ><button onclick='sendMoveDirectoryMusiqueInt(\""+pathNav+"\",\""+ldm[i]+"\")' style='width:60%; height:40%;background-color: Transparent;background-repeat:no-repeat; font-size: 30px;'>"+ldm[i]+"</button><button style='width:30%;height:50%; margin-left: 68%;' onclick='sendListeDossierDunDossierMusiquea(\""+ldm[i]+"\",\""+currentpath+"\")'>open</button></li>");
			
		}else{
			currentpath=ldm[0];
			paths.push(currentpath);
			indexpath++;
			console.log(indexpath);
			console.log(paths[0]);
			console.log(dossierCourant);	
		}
	}
}
function onreceiveListeDossierMusique(channelId, data,k) {
	currentlocation="listeDossierMusqiue";
	console.log(currentlocation);
	while(ldm.length) {
	    ldm.pop();
	}
	$("#ActionChansanMusique").remove();
	v = new String(data);
	var a = v.split(":");
	var i;
	for( i=0; i<a.length;i++){
		if(a[i]== "null"){
			a.	array.splice(i, 1);
			console.log(a);
		}
	}
	for(j=0; j<a.length;j++){
		if(a[j].indexOf("png")==-1){
		 ldi.push(a[j]+":");
		}
	}
	
	console.log(currentlocation);
	$("#content").append("<div id='resultDMBoar'></div>");
	for(i=0;i<a.length;i++){
			  $("#resultDMBoar").append("<li ><button onclick='sendMovefileMusiqueInt(\""+pathNav+"\",\""+ldm[i]+"\")'>"+a[i]+"</button></li><br/>"); 
	}
	
}
function onreceiveListeImage(channelId, data) {
	v = new String(data);
	 a = v.split(":");
	var i;
	var j;
	for( i=0; i<a.length;i++){
		if(a[i]== "null"){
			a.	array.splice(i, 1);
			console.log(a);
		}
	}
	var x=0;
	for(j=0; j<a.length;j++){
		if(a[j].indexOf("png")==-1){
		 ldi.push(a[j]+":");
		 //x++; 
		}
	}
	for(j=0; j<a.length;j++){
		console.log(ldi[j]);
	}
	for(i=0;i<a.length;i++){
		if(a[i].indexOf("png")==-1){
			//console.log(ldm);
			  $("#resultDI").append("<li onclick='actionDossierImage(\""+a[i]+"\");'><button>"+a[i]+"</button></li><br/>");
			 
		}else{
			//console.log(ldm);
			 $("#resultMI").append("<li onclick='actionImage(\""+a[i]+"\",\""+ldi+"\");'><button>"+a[i]+"<button></li><br/>");
		}
    
	}
	//$("#resultBoard").append("</ul>");
}
function  onreceiveMoveFileMusique(channelId, data){
	alert("moved succefully");
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 $("#resultDMBoard").remove();
	 $("#ActionChansanMusique").remove();
	 $("#liste").remove();
	 //$("#resultboard").remove();
	 sendListeMusique();
	 document.getElementById('location').innerHTML="Music";
}
function  onreceiveMoveFolderMusique(channelId, data){
	alert("Moved succefully");
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 $("#resultDMBoard").remove();
	 $("#liste").remove();
	 //$("#resultboard").remove();
	 sendListeMusique();
	 document.getElementById('location').innerHTML="Music";
}
function onreceiveMoveFolderToMusique(channelId, data){
	alert("Moved succesfully");
	for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 $("#ActionDossierMusique").remove();

	 //$("#resultboard").remove();
	 sendListeMusique();
	 document.getElementById('location').innerHTML="Music";
}
function  onreceiveMoveFileImage(channelId, data){
	alert(data);
}
function fetch() {
	try {
		SASocket.setDataReceiveListener(onreceive);
		SASocket.sendData(CHANNELID, "Hello Accessory!");
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}

(function() {
	window.addEventListener('tizenhwkey', function(e) {
		/* For the flick down gesture */
		if (e.keyName == "back")
		{
			 if(currentlocation=="ActionDossierMusique"){
				 if(indexpath>1){
				 $("#ActionDossierMusique").remove();
				 console.log(paths[indexpath]);
				 indexpath=indexpath-1;
				 paths.splice(indexpath,1);
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 sendListeDossierMusique(dossierCourant, paths[indexpath-1]);
				 }else{
					 $("#ActionDossierMusique").remove();
					 indexpath=indexpath-1;
					 console.log(paths[indexpath]);
					 sendListeMusique();
				 }
			 }else if(currentlocation=="listmusicplay"){
				 $("#lecteurallmusic").remove();
				 $("#pauseallmusic").remove();
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 //sendListeMusique();
				 //document.getElementById('location').innerHTML="Music";
				 try {
						SASocket.setDataReceiveListener(onreceivestoplistMusique);
						//console.log(nom);
						SASocket.sendData(CHANNELID , "stopmusic:");
						} catch(err) {
							console.log("exception [" + err.name + "] msg[" + err.message + "]");
						}
						 document.getElementById('location').innerHTML="Welcome";
						 currentlocation="acceuilleeeee";
						 console.log(currentlocation);
						// connect();
							$("#content").append("<div id='buttonn' class='ui-grid-col-1 button-group-height' style='margin-top: 10%;'></div>");
							//$("#buttonn").append("<button type= 'button' class='btn' onclick='connect();>Connect</button>");
							$("#buttonn").append("<button type='button' class='btn' onclick='sendListeMusique();'>Music</button><br/><br/>");
							$("#buttonn").append("<button type='button' class='btn' onclick='sendCdossierMusique();'>Create Folder</button><br/><br/>");
							$("#buttonn").append("<button type='button' class='btn' onclick='sendplayallmusic();'>My Songs</button>");
							$("#action").hide();
							$("#Move").show();
						 }else if(currentlocation=="listeDossierMusqiue"){
				 if(indexpath>1){
					 $("#resultM").remove();
					 $("#resultDMBoard").remove();
					 $("#resultDMBoar").remove();
					 $("#resultboard").remove();
					 console.log(paths[indexpath]);
					 indexpath=indexpath-1;
					 paths.splice(indexpath,1);
					 sendListeDossierMusique(dossierCourant, paths[indexpath-1]);
					 for(var k=0;k<ldm.length;k++){
						 ldm.pop();
					 }
					 for(var k=0;k<ldm.length;k++){
						 ldm.pop();
					 }
					 for(var k=0;k<ldm.length;k++){
						 ldm.pop();
					 }
					 }else{
						 $("#resultboard").remove();
						 $("#resultDMBoard").remove();
						 $("#resultDMBoar").remove();
						 indexpath=indexpath-1;
						 console.log(paths[indexpath]);
						 sendListeMusique();
						 for(var k=0;k<ldm.length;k++){
							 ldm.pop();
						 }
						 for(var k=0;k<ldm.length;k++){
							 ldm.pop();
						 }
						 for(var k=0;k<ldm.length;k++){
							 ldm.pop();
						 }
						 for(var k=0;k<ldm.length;k++){
							 ldm.pop();
						 }
						 for(var k=0;k<ldm.length;k++){
							 ldm.pop();
						 }
						 for(var k=0;k<ldm.length;k++){
							 ldm.pop();
						 }
					 }
			 }else if(currentlocation=="listemusique"){
				 //disconnect();
				 $("#resultM").remove();
				 $("#resultboard").remove();
				 document.getElementById('location').innerHTML="Welcome";
				 currentlocation="acceuilleeeee";
				 console.log(currentlocation);
				// connect();
					$("#content").append("<div id='buttonn' class='ui-grid-col-1 button-group-height' style='margin-top: 10%;'></div>");
					//$("#buttonn").append("<button type= 'button' class='btn' onclick='connect();>Connect</button>");
					$("#buttonn").append("<button type='button' class='btn' onclick='sendListeMusique();'>Music</button><br/><br/>");
					$("#buttonn").append("<button type='button' class='btn' onclick='sendCdossierMusique();'>Create Folder</button><br/><br/>");
					$("#buttonn").append("<button type='button' class='btn' onclick='sendplayallmusic();'>My Songs</button>");
					$("#action").hide();
					$("#Move").show();
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				
			 }else if(currentlocation=="listemusiqueaa"){
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 $("#resultM").remove();
				 $("#resultboard").remove();
				 currentlocation="listemusique";
				 sendListeMusique();
				 document.getElementById('location').innerHTML="Music";
				 
			 }else if(currentlocation=="play"){
				 $("#playmusic").remove();
				 $("#pausemusic").remove();
				 $("#resultboard").remove();
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				
				 document.getElementById('location').innerHTML="Music";
				 try {
						SASocket.setDataReceiveListener(onreceiveMoveFileMusique);
						//console.log(nom);
						SASocket.sendData(CHANNELID , "stopmusic:");
						} catch(err) {
							console.log("exception [" + err.name + "] msg[" + err.message + "]");
						}
						 sendListeMusique();
			 }
			 else if(currentlocation=="acceuilleeeee".toString()){
				 disconnect();
				 $("#buttonn").remove();
				 window.location.href="IndexBilel.html";
			 }else if(currentlocation="actionchansanmusique".toString()){
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 for(var k=0;k<ldm.length;k++){
					 ldm.pop();
				 }
				 $("#ActionChansanMusique").remove();
				 sendListeMusique();
				 document.getElementById('location').innerHTML="Music";
			 }
		}
	});

}());

//waliiiiiiid


function onrecievetitre(channelId, data) {
	//alert(data);
	document.getElementById('titreeeee').innerHTML=data;
	$("#textbox300").hide();
}

function getTitre() {
	connect();
	try {
		SASocket.setDataReceiveListener(onrecievetitre);
		SASocket.sendData(CHANNELID, "getTitre");
		
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
//waliiiiiiiiiiiiiiiiiiiiiiiiiiiiiid

function sendListeMusique(){
	$("#action").show();
	$("#buttonn").remove();
    $("#resultboard").remove();
    $("#resultboard").remove();
	try {
	SASocket.setDataReceiveListener(onreceiveListeMusique);
	SASocket.sendData(CHANNELID , "listemusique");
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendListeMusiqueA(){
	try {
		//document.getElementById('button').style.visibility=="hidden"
	SASocket.setDataReceiveListener(onreceiveListeMusique);
	SASocket.sendData(CHANNELID , "listemusique");
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendListeDossierMusique(a,b){
	 $("#resultDMBoard").remove();
	 $("#resultDMBoar").remove();
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	dossierCourant=a;
	document.getElementById('location').innerHTML=a.toString();
	console.log(dossierCourant);
	console.log(b+a);
	currentpatha=b+a;
	$("#ActionDossierMusique").remove();
	console.log(b+a);
	console.log(indexpath);
	console.log(paths[indexpath-1]);
	try {
		//document.getElementById('button').style.visibility=="hidden"
	SASocket.setDataReceiveListener(onreceiveListeMusiqueaa);
	SASocket.sendData(CHANNELID , "listerundossiermusicale:"+b+a+"/");
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendListeDossierDunDossierMusique(a,b){
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	$("#resultboard").remove();
	
	DossenNav=DossenNav+1;
	if(a!=""){
	DossNavigated.push(a);
	console.log(DossNavigated);
	pathNav=pathNav+a+"/";
	console.log("path de navigation est "+pathNav);
	dossierCourant=a;
	console.log(dossierCourant);
	}
	//$("#resultboard").remove();
	//$("#ActionDossierMusique").remove();
	 $("#resultDMBoard").remove();
	 $("#liste").remove();
	console.log(b+a);
	//console.log(indexpath);
	console.log(paths[indexpath-1]);
	try {
		//document.getElementById('button').style.visibility=="hidden"
	SASocket.setDataReceiveListener(onreceiveListeDesDossierMusique);
	SASocket.sendData(CHANNELID , "listerundossiermusicale:"+b+a+"/");
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendListeDossierDunDossierMusiquea(a,b){
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	console.log(DossNavigated);
	if(a!=""){
		DossNavigated.push(a);
		console.log(DossNavigated);
		pathNav=pathNav+a+"/";
		console.log("path de navigation est "+pathNav);
		dossierCourant=a;
		console.log(dossierCourant);
		dossierCourant=a;
		
	//$("#resultboard").remove();
	$("#resultDMBoard").remove();
	console.log(dossierCourant);
	//$("#ActionDossierMusique").remove();
	console.log(b+a);
	console.log(indexpath);
	console.log(paths[indexpath-1]);
	try {
	SASocket.setDataReceiveListener(onreceiveListeDesDossierMusique1);
	SASocket.sendData(CHANNELID , "listerundossiermusicale:"+b+a+"/");
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
	}else{
		 for(var k=0;k<ldm.length;k++){
			 ldm.pop();
		 }
		 for(var k=0;k<ldm.length;k++){
			 ldm.pop();
		 }
		 for(var k=0;k<ldm.length;k++){
			 ldm.pop();
		 }
		 for(var k=0;k<ldm.length;k++){
			 ldm.pop();
		 }
		 for(var k=0;k<ldm.length;k++){
			 ldm.pop();
		 }
		 for(var k=0;k<ldm.length;k++){
			 ldm.pop();
		 }
		$("#resultDMBoard").remove();
		console.log(dossierCourant);
		//$("#ActionDossierMusique").remove();
		console.log(b+a);
		console.log(indexpath);
		console.log(paths[indexpath-1]);
		try {
		SASocket.setDataReceiveListener(onreceiveListeDesDossierMusique1);
		SASocket.sendData(CHANNELID , "listerundossiermusicale:"+b);
		} catch(err) {
			console.log("exception [" + err.name + "] msg[" + err.message + "]");
		}
	}
}
function sendDossierListeMusique(){
	try {
		//document.getElementById('button').style.visibility=="hidden"
	SASocket.setDataReceiveListener(onreceiveListeDossierMusique);
	SASocket.sendData(CHANNELID , "listedossiermusique");
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendListeImage(){
	try {
	SASocket.setDataReceiveListener(onreceiveListeImage);
	SASocket.sendData(CHANNELID , "listeimage");
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendCdossierMusique(){
	console.log(i);
		try {
		SASocket.setDataReceiveListener( onreceiveCdossierMusique);
		SASocket.sendData(CHANNELID , "creerdossiermusique:"+datetime+"_"+i);
		} catch(err) {
			console.log("exception [" + err.name + "] msg[" + err.message + "]");
		}
		i++;
		console.log(i);
}
function sendCdossierImusique(a){
	console.log(j);
	console.log(datetime);
	console.log(currentpath+a+"/"+datetime);
	try {
		SASocket.setDataReceiveListener( onreceiveCdossierMusiqueI);
		SASocket.sendData(CHANNELID , "creerInternedossiermusique:"+currentpath+a+":"+datetime+"_"+j);
		} catch(err) {
			console.log("exception [" + err.name + "] msg[" + err.message + "]");
		}
		j++;
		console.log(i);
}
function sendCdossierImage(nom){
			try {
			SASocket.setDataReceiveListener(onreceiveCdossierImage);
			SASocket.sendData(CHANNELID , "creerdossierimage:"+nom);
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}	
}
function sendMovefileMusique(nom,b){
	var k;
	var j=0;
	console.log(fichieradeplacer);
	console.log(b);
	console.log(firstpath);
	console.log(pathNav+b);
	try {
	SASocket.setDataReceiveListener(onreceiveMoveFileMusique);
	console.log(nom);
	SASocket.sendData(CHANNELID , "deplacerfichermusique:"+firstpath+":"+(pathNav+b).toString()+":"+fichieradeplacer.toString());
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendMoveDirectoryMusique(nom,b){
	var k;
	var j=0;
	console.log(fichieradeplacer);
	console.log(b);
	console.log(firstpath);
	console.log(pathNav+b);
	try {
	SASocket.setDataReceiveListener(onreceiveMoveFolderMusique);
	console.log(nom);
	SASocket.sendData(CHANNELID , "deplacerdossiermusique:"+firstpath.toString()+":"+(pathNav+b).toString()+":"+fichieradeplacer.toString()+":"+b.toString());
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendMoveDirectoryMusiqueInt(nom,b){
	var k;
	var j=0;
	console.log(fichieradeplacer);
	console.log(b);
	console.log(firstpath);
	console.log(pathNav+b);
	console.log(currentpath);	
	try {
	SASocket.setDataReceiveListener(onreceiveMoveFolderMusique);
	console.log(nom);
	SASocket.sendData(CHANNELID , "deplacerinterdossiermusique:"+firstpath.toString()+":"+(currentpath+b).toString()+":"+fichieradeplacer.toString()+":"+b.toString());
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendMovefileToMusic(a){
	console.log(currentpath+"/"+a);
	var k;
	var j=0;
	console.log(firstpath);
	try {
	SASocket.setDataReceiveListener(onreceiveMoveFileMusique);
	//console.log(nom);
	SASocket.sendData(CHANNELID , "deplacfichermusiquetomusic:"+currentpath+":"+"/storage/emulated/0/Music/"+":"+a.toString());
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendMoveDirectoryToMusic(a){
	console.log(currentpath+"/"+a);
	var k;
	var j=0;
	//console.log(firstpath);
	try {
	SASocket.setDataReceiveListener(onreceiveMoveFolderToMusique);
	//console.log(nom);
	SASocket.sendData(CHANNELID , "deplacermusicdossiertomusic:"+currentpath+":"+"/storage/emulated/0/Music/"+":"+a.toString());
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}

function sendSupprimerfichiermusique(){
	
}

function sendplayallmusic(){
	currentlocation="listmusicplay";
	$("#buttonn").remove();
	$("#pauseallmusic").remove();
	$("#content").append("<div style='margin-top:25%;' id='lecteurallmusic'><div>");
	$("#lecteurallmusic").append("<ul id='listbut'><li><button style='background-color: transparent;width:10%;' onclick='volumemoins();'><img src='./images/icone/1430720375_black_1_speaker_plus-128.png' style='width:100%; height:100%'/></button><button style='width:10%; background-color: transparent; margin-left:80%; margin-top:-18%;' onclick='volumeplus();'><img src='./images/icone/1430720370_black_1_speaker_minus-128.png' style='width:100%; height:100%'/></button></li><br/></ul>");
	$("#listbut").append("<li><button style='width:30%; background-color: transparent;' onclick='prevsong();'><img src='./images/icone/1430720367_black_4_audio_step_back-128.png' style='width:30%; height;30%'/></button><button style='width:40%; background-color: transparent;' onclick='pauselist();'><img src='./images/icone/1430720231_icon-pause-128.png' style='width:30%; height;30%'/></button><button style='width:30%; background-color: transparent;' onclick='nextsong();'><img src='./images/icone/1430720314_black_4_audio_step_forward-128.png' style='width:30%; height:30%'/></button></li>");
	 try {
			SASocket.setDataReceiveListener(onreceiveplaylistMusique);
			//console.log(currentpath+a);
			SASocket.sendData(CHANNELID , "playlistmusic:");
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
}
function sendreplaylise(){
	currentlocation="listmusicplay";
	$("#buttonn").remove();
	$("#pauseallmusic").remove();
	$("#content").append("<div style='margin-top:25%;' id='lecteurallmusic'><div>");
	$("#lecteurallmusic").append("<ul id='listbut'><li><button style='background-color: transparent;width:10%; ' onclick='volumemoins();'><img src='./images/icone/1430720375_black_1_speaker_plus-128.png' style='width:100%; height:100%'/></button><button style='width:10%; background-color: transparent; margin-left:80%; margin-top:-18%;' onclick='volumeplus();'><img src='./images/icone/1430720370_black_1_speaker_minus-128.png' style='width:100%; height:100%'/></button></li><br/></ul>");
	$("#listbut").append("<li><button style='width:30%; background-color: transparent;' onclick='prevsong();'><img src='./images/icone/1430720367_black_4_audio_step_back-128.png' style='width:30%; height;30%'/></button><button style='width:40%; background-color: transparent;' onclick='pauselist();'><img src='./images/icone/1430720231_icon-pause-128.png' style='width:30%; height;30%'/></button><button style='width:30%; background-color: transparent;' onclick='nextsong();'><img src='./images/icone/1430720314_black_4_audio_step_forward-128.png' style='width:30%; height:30%'/></button></li>");
	 try {
			SASocket.setDataReceiveListener(onreceiveplaylistMusique);
			console.log(currentpath+a);
			SASocket.sendData(CHANNELID , "playlistmusic:");
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
}
function sendMovefileMusiqueInt(nom,b){
	var k;
	var j=0;
	console.log(fichieradeplacer);
	console.log(firstpath);
	//console.log(nom);
	console.log(currentpath+b);
	var h=nom+b;
	console.log((nom+b).toString());
	//console.log(f);
	//console.log(currentpath);
	try {
	SASocket.setDataReceiveListener(onreceiveMoveFileMusique);
	console.log(nom);
	SASocket.sendData(CHANNELID , "deplacermusiqueficherint:"+firstpath.toString()+":"+(currentpath+b+"/").toString()+":"+fichieradeplacer.toString());
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}
}
function sendMovefileImage(path,a){
	
	try {
	SASocket.setDataReceiveListener(onreceiveMoveFileImage);
	SASocket.sendData(CHANNELID ," deplacerfichierimage:"+path+":"+k);
	} catch(err) {
		console.log("exception [" + err.name + "] msg[" + err.message + "]");
	}	
}
function actionchansanMusique(v,h){
	if(currentpath=="/storage/emulated/0/Music/".toString()){
	//console.log(h);
	$("#resultboard").remove();
	console.log(v);
	currentlocation="actionchansanmusique";
	$("#content").html("<div id='ActionChansanMusique' style='font-weight: normal;'></div>");
	$("#ActionChansanMusique").append("<ul><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='MovefileMusique(\""+h+"\",\""+v+"\")' ><h1 style='color: white;'>Move<h1></li><br/><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='play(\""+v+"\");'><h1 style='color: white;'>play<h1></li></ul>");
	}else{
		$("#resultboard").remove();
		currentlocation="actionchansanmusique";
		$("#content").html("<div id='ActionChansanMusique' style='font-weight: normal;'></div>");
		$("#ActionChansanMusique").append("<ul><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='MovefileMusiqueInt(\""+h+"\",\""+v+"\")' ><h1 style='color: white;'>Move<h1></li><br/><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='play(\""+v+"\");'><h1 style='color: white;'>play<h1></li><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='sendMovefileToMusic(\""+v+"\");'><h1 style='color: white;'>Move to Music<h1></li></ul>");
	}
}
function actionDossierMusique(v,k){
	if(currentpath=="/storage/emulated/0/Music/".toString()){
	$("#resultboard").remove();
	console.log(currentpath);
	console.log(indexpath);
	currentlocation="ActionDossierMusique";
	$("#content").html("<div id='ActionDossierMusique' style=' font-weight: normal;'></div>")
	$("#ActionDossierMusique").append("<ul><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='MoveDirectoryMusique(\""+k+"\",\""+v+"\")'><h1 style='color: white;'>Move</h1></li><br/><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='sendListeDossierMusique(\""+v+"\",\""+currentpath+"\");'><h1 style='color: white;'>open<h1></li><br/><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='sendCdossierImusique(\""+v+"\");'><h1 style='color: white;'>create Folder</h1></li></ul>");
	currentlocation = "ActionDossierMusique";
	 console.log(currentlocation);
	 console.log(currentpath); }
	else{
		 $("#resultboard").remove();
			console.log(currentpath);
			console.log(indexpath);
			currentlocation="ActionDossierMusique";
			$("#content").html("<div id='ActionDossierMusique' style=' font-weight: normal;'></div>")
			$("#ActionDossierMusique").append("<ul><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='MoveDirectoryMusiqueInt(\""+k+"\",\""+v+"\")'><h1 style='color: white;'>Move</h1></li><br/><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='sendListeDossierMusique(\""+v+"\",\""+currentpath+"\")'><h1 style='color: white;'>ouvrir<h1></li><br/><li style= 'border-bottom:  3px solid white; border-width: 120%;' onclick='sendCdossierImusique(\""+v+"\");'><h1 style='color: white;'>creerDossier</h1></li><br/><li style= 'border-bottom:  3px solid black; border-width: 120%;' onclick='sendMoveDirectoryToMusic(\""+v+"\");'><h1 style='color: white;'>Move to Music</h1></li></ul>");
			currentlocation = "ActionDossierMusique";
			 console.log(currentlocation);
			 console.log(currentpath);
		 
	 }
}
 function actionImage(h,v){
	
	   
}
 function actionDossierImage(){
		
	
 }
 function MovefileMusique(v,k){
	 document.getElementById('location').innerHTML="Move";
	 fichieradeplacer=k;
	 firstpath=currentpath;
	 console.log("fichier a deplacer" +fichieradeplacer);
	 console.log("fichier a deplacer" +firstpath);
	 $("#action").show();
	 $("#resultDMBoard").remove();
	 currentlocation="listeDossierMusqiue";
	 console.log(currentlocation);
	 $("#ActionChansanMusique").remove();
	 $("#content").append("<div id='resultDMBoard'></div>")
	 $("#resultDMBoard").append("<ul id='liste'></ul>");
	 //console.log(v);
	// console.log(ldm);
		console.log(k);
		console.log(pathNav);
		var i;
		for(i=0;i<ldm.length;i++){
			if(v[i]!=null && ldm[i]!=""){
				//  $("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%;'><a  onclick='sendMovefileMusique(\""+pathNav+"\",\""+ldm[i]+"\")' ></a><h1 style='color: white;'><img src='./images/Open_Folder.jpga359780b-fe23-4fbb-86ae-6ec47653a3ddLarger.jpg' style='width: 10%;height: 10%;'/>"+ldm[i]+"</h1><button style='width:30%;height:50%; margin-left: 68%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>OU</button></li>");
				  $("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%;' ><button onclick='sendMovefileMusique(\""+pathNav+"\",\""+ldm[i]+"\")' style='width:60%; height:40%;background-color: Transparent;background-repeat:no-repeat; font-size: 30px;'>"+ldm[i]+"</button><button style='width:30%;height:50%; margin-left: 68%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>open</button></li>");
			}
		}
	
 }
 function MovefileMusiqueInt(v,k){
	 document.getElementById('location').innerHTML="Move";
	 fichieradeplacer=k;
	 firstpath=currentpath;
	 console.log("fichier a deplacer" +fichieradeplacer);
	 console.log("fichier a deplacer" +firstpath);
	 $("#action").show();
	 $("#resultDMBoard").remove();
	 currentlocation="listeDossierMusqiue";
	 console.log(currentlocation);
	 $("#ActionChansanMusique").remove();
	 $("#content").append("<div id='resultDMBoard'></div>")
	 $("#resultDMBoard").append("<ul id='liste'></ul>");
	 //console.log(v);
	// console.log(ldm);
		console.log(k);
		console.log(pathNav);
		var i;
		for(i=0;i<ldm.length;i++){
			if(v[i]!=null && ldm[i]!=""){
			//	  $("#liste").append("<li style= 'border: 1px solid white;'><a> onclick='sendMovefileMusiqueInt(\""+pathNav+"\",\""+ldm[i]+"\")'></a><h1 style='color: white;'><img src='./images/Open_Folder.jpga359780b-fe23-4fbb-86ae-6ec47653a3ddLarger.jpg' style='width: 10%;height: 10%;'/>"+ldm[i]+"</h1><button style='width:20%;height:40%; margin-left: 90%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>OU</button></li>");
				  $("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%;' ><button onclick='sendMovefileMusiqueInt(\""+pathNav+"\",\""+ldm[i]+"\")' style='width:60%; height:40%;background-color: Transparent;background-repeat:no-repeat; font-size: 30px;'>"+ldm[i]+"</button><button style='width:30%;height:50%; margin-left: 68%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>open</button></li>");
			}
		}
	
 }
 function MoveDirectoryMusique(v,k){
	 document.getElementById('location').innerHTML="Move";
	 fichieradeplacer=k;
	 firstpath=currentpath;
	 console.log("fichier a deplacer" +fichieradeplacer);
	 console.log("fichier a deplacer" +firstpath);
	 $("#action").show();
	 $("#resultDMBoard").remove();
	 currentlocation="listeDossierMusqiue";
	 console.log(currentlocation);
	 $("#ActionDossierMusique").remove();
	 $("#content").append("<div id='resultDMBoard'></div>")
	 $("#resultDMBoard").append("<ul id='liste'></ul>");
	 //console.log(v);
	// console.log(ldm);
		console.log(k);
		console.log(pathNav);
		var i;
		for(i=0;i<ldm.length;i++){
			if(v[i]!=null && ldm[i]!="" && ldm[i]!=k){
				//  $("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%' onclick='sendMoveDirectoryMusique(\""+k+"\",\""+ldm[i]+"\")' ><h1 style='color: white;'><img src='./images/Open_Folder.jpga359780b-fe23-4fbb-86ae-6ec47653a3ddLarger.jpg' style='width: 10%;height: 10%;'/>"+ldm[i]+"</h1><button style='width:20%;height:40%; margin-left: 90%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>OU</button></li>");
				$("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%' ><button onclick='sendMoveDirectoryMusique(\""+k+"\",\""+ldm[i]+"\")' style='width:60%; height:40%;background-color: Transparent;background-repeat:no-repeat; font-size: 30px;'>"+ldm[i]+"</button><button style='width:20%;height:40%; margin-left: 90%;' onclick='sendListeDossierDunDossierMusiquea(\""+ldm[i]+"\",\""+currentpath+"\")'>open</button></li>");
			}  
		}
 }
 function MoveDirectoryMusiqueInt(v,k){
	 document.getElementById('location').innerHTML="Move";
	 fichieradeplacer=k;
	 firstpath=currentpath;
	 console.log("fichier a deplacer" +fichieradeplacer);
	 console.log("fichier a deplacer" +firstpath);
	 $("#action").show();
	 $("#resultDMBoard").remove();
	 currentlocation="listeDossierMusqiue";
	 console.log(currentlocation);
	 $("#ActionDossierMusique").remove();
	 $("#content").append("<div id='resultDMBoard'></div>")
	 $("#resultDMBoard").append("<ul id='liste'></ul>");
	 //console.log(v);
	// console.log(ldm);
		console.log(k);
		console.log(pathNav);
		var i;
		for(i=0;i<ldm.length;i++){
			if(v[i]!=null && ldm[i]!="" && ldm[i]!=k){
				//  $("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%' onclick='sendMoveDirectoryMusique(\""+k+"\",\""+ldm[i]+"\")' ><h1 style='color: white;'><img src='./images/Open_Folder.jpga359780b-fe23-4fbb-86ae-6ec47653a3ddLarger.jpg' style='width: 10%;height: 10%;'/>"+ldm[i]+"</h1><button style='width:20%;height:40%; margin-left: 90%;' onclick='sendListeDossierDunDossierMusique(\""+ldm[i]+"\",\""+currentpath+"\")'>OU</button></li>");
				$("#liste").append("<li style= 'border-bottom:  3px solid white; border-width: 120%' ><button onclick='sendMoveDirectoryMusiqueInt(\""+k+"\",\""+ldm[i]+"\")' style='width:60%; height:40%;background-color: Transparent;background-repeat:no-repeat; font-size: 30px;'>"+ldm[i]+"</button><button style='width:20%;height:40%; margin-left: 90%;' onclick='sendListeDossierDunDossierMusiquea(\""+ldm[i]+"\",\""+currentpath+"\")'>open</button></li>");
			}  
		}
 }
 function MovefileImage(v,k){
	    //sendDossierListeMusique();
	    //sendDossierListeMusique();
	  /*  h=v.split(":");
	    $("#button").hide();
		$("#CreerDossierImage").hide();
		$("#CreerDossierMusique").hide();
		$("#ActionImage").hide();
		$("#ActionChansanMusique").hide();
		$("#ActionDossierMusique").hide();
		$("#resultBoard").hide();
		$("#resultBoardI").hide();
		$("#resultDMBoard").hide();
		$("#resultDIBoard").show();
		$("#resultDIBoard").append("<ul>");
		//console.log(v.length);
		console.log(k);
		var i;
		for(i=0;i<h.length;i++){
			//$("#resultBoard").append("<li>"+a[i]+"</li>");
			if(h[i]!=null && h[i]!=""){
				  $("#resultDIBoard").append("<li><button onclick='sendMovefileImage(\""+k+"\",\""+h[i]+"\")'>"+h[i]+"</button></li><br/>");
			}
		}
		$("#resultDIBoard").append("</ul>");
		// $("#resultDMBoar").append("<ul><li>"+a+"</li></ul>");*/
	 }
 function play(a){
	 currentlocation="play";
	 console.log("hhaaaa");
	 $("#ActionChansanMusique").remove();
	 $("#pausemusic").remove();
	 $("#content").append("<div id='playmusic' style='font-weight: normal; margin-top:25%; margin-left:1%; height:130%'></div>");
	 $("#playmusic").append("<ul style=' height:40%;'><li style='width:100%; height:40%; background-color: black;' onclick='pause(\""+a+"\");'><button style='height:100%; margin-left:43%; background-color: black; border:none;'><img id='imge' src='./images/pause_icon.png'/></button></li><br/><li style='width:100%; height:40%; background-color: black;' onclick='volumeplus();' ondrag='volumeplus();'><button style='height:100%; margin-left:43%; background-color: black; border:none;'><img src='./images/minus.png' style='width:50px; height:50px;'/></button></li><br/><li style='width:100%; height:40%; background-color: black;' onclick='volumemoins();' ondrag='volumemoins();'><button style='height:100%; margin-left:43%; background-color: black; border:none;'><img src='./images/Green_plus_icon.png' style='width:50px; height:50px;'/></button></li></ul>");
	 try {
			SASocket.setDataReceiveListener(onreceiveplayMusique);
			console.log(currentpath+a);
			SASocket.sendData(CHANNELID , "playmusic:"+currentpath+":"+a);
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
 }
 function pause(b){
	 currentlocation="play";
	 console.log("hhaaaa");
	 $("#ActionChansanMusique").remove();
	 $("#playmusic").remove();
	 $("#content").append("<div id='pausemusic' style='font-weight: normal; margin-top:25%; margin-left:1%; height:130%'></div>");
	 $("#pausemusic").append("<ul style=' height:40%;'><li style='width:100%; height:40%; background-color: black;' onclick='play(\""+b+"\");'><button style='height:100%; margin-left:43%; background-color: black; border:none;'><img id='imge' src='./images/play_icon.png'/></button></li><br/><li style='width:100%; height:40%; background-color: black;' onclick='volumeplus(); ondrag='volumeplus();''><button style='height:100%; margin-left:43%; background-color: black; border:none;'><img src='./images/minus.png' style='width:50px; height:50px;'/></button></li><br/><li style='width:100%; height:40%; background-color: black;' onclick='volumemoins();' ondrag='volumemoins();'><button style='height:100%; margin-left:43%; background-color: black; border:none;'><img src='./images/Green_plus_icon.png' style='width:50px; height:50px;'/></button></li></ul>");
	 try {
			SASocket.setDataReceiveListener(onreceiveMoveFileMusique);
			//console.log(nom);
			SASocket.sendData(CHANNELID , "pausemusic:");
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
 }
 function pauselist(){
	 currentlocation="listmusicplay";
		$("#buttonn").remove();
		$("#lecteurallmusic").remove();
		$("#content").append("<div style='margin-top:25%;' id='pauseallmusic'><div>");
		$("#pauseallmusic").append("<ul id='listbut'><li><button style='background-color: transparent;width:10%; ' onclick='volumemoins();'><img src='./images/icone/1430720375_black_1_speaker_plus-128.png' style='width:100%; height:100%'/></button><button style='width:10%; background-color: transparent; margin-left:80%; margin-top:-18%;' onclick='volumeplus();'><img src='./images/icone/1430720370_black_1_speaker_minus-128.png' style='width:100%; height:100%'/></button></li><br/></ul>");
		$("#listbut").append("<li><button style='width:30%; background-color: transparent;'><img src='./images/icone/1430720367_black_4_audio_step_back-128.png' style='width:30%; height;30%'/></button><button style='width:40%; background-color: transparent;' onclick='sendreplaylise();'><img src='./images/icone/1430720205_icon-play-128.png' style='width:30%; height;30%'/></button><button style='width:30%; background-color: transparent;'><img src='./images/icone/1430720314_black_4_audio_step_forward-128.png' style='width:30%; height:30%'/></button></li>");
	 try {
			SASocket.setDataReceiveListener(onreceiveplaylistMusique);
			console.log(currentpath+a);
			SASocket.sendData(CHANNELID , "pauselist:");
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
 }
 function prevsong(){
	 try {
			SASocket.setDataReceiveListener(onreceiveprevMusique);
			console.log(currentpath+a);
			SASocket.sendData(CHANNELID , "prevsong:");
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
 }
 
 function nextsong(){
	 try {
			SASocket.setDataReceiveListener(onreceivenextMusique);
			//console.log(currentpath+a);
			SASocket.sendData(CHANNELID , "nextsong:");
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
 }
 
 function volumemoins(){
	 try {
			SASocket.setDataReceiveListener(onreceiveMoveFileMusique);
			//console.log(nom);
			SASocket.sendData(CHANNELID , "volumeplus:");
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
 }
function volumeplus(){
	 try {
			SASocket.setDataReceiveListener(onreceiveMoveFileMusique);
			//console.log(nom);
			SASocket.sendData(CHANNELID , "moinsvolume:");
			} catch(err) {
				console.log("exception [" + err.name + "] msg[" + err.message + "]");
			}
 }
 
 function lancer() {
	 document.getElementById('location').innerHTML="Welcome";
	 currentlocation="acceuilleeeee";
	 console.log(currentlocation);
	 connect();
		$("#content").append("<div id='buttonn' class='ui-grid-col-1 button-group-height' style='margin-top: 10%;'></div>");
		//$("#buttonn").append("<button type= 'button' class='btn' onclick='connect();>Connect</button>");
		$("#buttonn").append("<button type='button' class='btn' onclick='sendListeMusique();'>Music</button><br/><br/>");
		$("#buttonn").append("<button type='button' class='btn' onclick='sendCdossierMusique();'>Create Folder</button><br/><br/>");
		$("#buttonn").append("<button type='button' class='btn' onclick='sendplayallmusic();'>My Songs</button>");
		$("#action").hide();
		$("#Move").show();
		//$("#content").append("</div>")
}
 function back(){
	 if(currentlocation=="ActionDossierMusique"){
		 if(indexpath>1){
		 $("#ActionDossierMusique").remove();
		 console.log(paths[indexpath]);
		 indexpath=indexpath-1;
		 paths.splice(indexpath,1);
		 sendListeDossierMusique(dossierCourant, paths[indexpath-1]);
		 }else{
			 $("#ActionDossierMusique").remove();
			 indexpath=indexpath-1;
			 console.log(paths[indexpath]);
			 sendListeMusique();
		 }
	 }else{
		 $("#ActionChansanMusique").remove();
		 sendListeMusique();
	 }
 }
 function valueChanged()
 {
	 searchIDsInt=[];
     if($('.chekbox').is(":checked")){   
    	 var i;
        console.log("qsdsqd");
       var total=$('input[name=doss]:checked').length;
       var searchIDs = $("#resultboard input:checkbox:checked").map(function(){
            return $(this).val();
          }).get(); // <----
          console.log(searchIDs);
          searchIDsInt=searchIDsInt.concat(searchIDs);
          console.log(searchIDsInt);
        console.log(total);
        for(i=0;i<total;i++){
        	console.log(searchIDsInt[i]);
        }
       
     }else{
    	 $("#action").hide();
     }
   
 }
 //var checkboxes = $(".chekbox");
function action(){
	if(currentlocation=="listemusique"){
	disconnect();
	window.location.href="IndexBilel.html"
}else if(currentlocation=="listemusiqueinterne"){
	// $("#resultboard").remove();
	var i=DossenNav-1;
	var j=DossenNav-1;
	DossenNav=DossenNav-1;
	 console.log("les dossier sont :"+DossNavigated);
	 console.log(DossenNav);
	 while (i>=0){
		 pathNav=pathNav.replace(DossNavigated[i]+"/","");
		 
		 i=i-1;
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	console.log(pathNav);
	console.log(DossNavigated);
	$('.myCheckbox').attr('checked', false);
	$("#resultDMBoard").remove();
		sendListeDossierDunDossierMusique("", "/storage/emulated/0/Music/");
		 while(j>=0){
			 DossNavigated.pop();
			 j=j-1;
			 }
	 console.log("les dossier sont :"+DossNavigated);
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 /*console.log(DossNavigated[DossenNav-1]);
	 pathNav = pathNav.replace(DossNavigated[DossenNav-1], "");
	 console.log(pathNav);
	 DossenNav=DossenNav-1;
	 console.log(DossenNav);
	 console.log(DossNavigated[DossenNav-1]);
	 console.log(pathNav);*/
	 //$("#resultDMBoard").remove();
	 //sendListeDossierDunDossierMusique(DossNavigated[DossenNav], current); 
}else if(currentlocation=="listeDossierMusqiue"){
	for(var i=0;i<searchIDsInt.length;i++){
		searchIDsInt.pop();
	}
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	 for(var k=0;k<ldm.length;k++){
		 ldm.pop();
	 }
	$('.myCheckbox').attr('checked', false);
	$("#resultDMBoard").remove();
   $("#resultboard").remove();
   pathNav="/storage/emulated/0/Music/";
   sendListeMusique();
}
}	 