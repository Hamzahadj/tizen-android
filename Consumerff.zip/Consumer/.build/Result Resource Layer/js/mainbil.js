
$(window).load(function(){
	document.addEventListener('tizenhwkey', function(e) {
        if((e.keyName == "back")&&(!($('#about').is(':hidden')))){
        	showacc();
        	alert("azeaz");
        }else{
            tizen.application.getCurrentApplication().exit();
			}});
	
});
function showacc( ) {
	$("#content").show();
	$("#content1").hide();
	$("#acceuil").show();
	$("#about").hide();
	
}

function showM( ) {
	$("#acceuil").hide();
	//$("#content").hide();
	//$("#content1").show();
	window.location.href="index.html"; 
}
function showAb(){
	$("#acceuil").hide();
	$("#about").show();
}

function showG( ) {
	$("#acceuil").hide();
	window.location.href="IndexH.html"
	
}
function showI( ) {
	$("#acceuil").hide();
	$("#gestionphone").hide();
	$("#gestionm").hide();
	$("#gestioni").hide();
	$("#reconizemusic").hide();
	$("#reconizeimage").show();
	$("#sharing").hide();
	
}
function showS( ) {
	$("#acceuil").hide();
	$("#gestionphone").hide();
	$("#gestionm").hide();
	$("#gestioni").hide();
	$("#reconizemusic").hide();
	$("#reconizeimage").hide();
	$("#sharing").show();
	
}
function showGI( ) {
	$("#acceuil").hide();
	$("#gestionphonea").hide();
	$("#gestionm").hide();
	$("#gestioni").show();
	$("#reconizemusic").hide();
	$("#reconizeimage").hide();
	$("#sharing").hide();
	
}
function showGM( ) {
	$("#acceuil").hide();
	$("#gestionphonea").hide();
	$("#gestionm").show();
	$("#gestioni").hide();
	$("#reconizemusic").hide();
	$("#reconizeimage").hide();
	$("#sharing").hide();
	
}



