var SOURCE_PATH = "file:///opt/usr/media/Sounds/www.amr"
var gTransferId = 0;

/* Alert message with toast popup of TAU */
function toastAlert(msg) {
	var toastMsg = document.getElementById("popupToastMsg");
	toastMsg.innerHTML = msg;
	tau.openPopup('#popupToast');
	console.log(msg);
}

function showMain(message) {
	tau.changePage('#main');
	if (message != undefined) {
		toastAlert(message);
	}
	gTransferId = 0;
}

var ftSuccessCb = {
	onsuccess : function () {
		toastAlert('Succeed to connect');
		//updateContents();
		sendFile(SOURCE_PATH);
	},
	onsendprogress : function (id, progress) {
		console.log('onprogress id : ' + id + ' progress : ' + progress);
		$('#sendprogress').attr('value', progress);
	},
	onsendcomplete : function (id, localPath) {
		$('#sendprogress').attr('value', 100);
		showMain('send Completed!! id : ' + id + ' localPath :' + localPath);
		window.location.href="getTitre.html";
		
	}
};

function clearList(reconnect) {
	console.log('clear List');
	$('.ui-listview').empty();
	if (reconnect) {
		$('.ui-listview').append('<input type="button" class="ui-btn ui-inline" value="Connect" onclick="reconnect();" style="width:100%;"/>');
	} else {
		$('.ui-listview').append('<li>BT Disconnected. Connection waiting...</li>');
	}
}

function reconnect() {
	$('.ui-listview').empty();
	sapFindPeer(function(){
		console.log('Succeed to find peer');
		ftInit(ftSuccessCb, function(err) {
			toastAlert('Failed to get File Transfer');
			clearList(true);
		});
	}, function(err){
		toastAlert('Failed to reconnect to service');
		clearList(true);
	});

}

function updateContents() {
	try {
		tizen.content.find(function(contents) {
			$('.ui-listview').empty();
			if (contents.length > 0) {
				for(var i = 0; i < contents.length ; i++) {
					console.log('name : ' + contents[i].title + ' URI : ' + contents[i].contentURI);
					var nameStr = (contents[i].title.length > 15) ? (contents[i].title.substring(0, 11) + '...') : contents[i].title;
					$('.ui-listview').append(
					        '<li><a onclick="sendFile(\'' + contents[i].contentURI + '\');">' + nameStr
					                + '</a></li>');
				}
				$('.ui-listview').append('<li><a onclick="updateContents();">Update contents...</a></li>');
			} else {
				$('.ui-listview').append('<li><a onclick="updateContents();">No items. Update contents</a></li>');
			}
		}, function(err) {
			console.log('Failed to find contents');
		});
	} catch(err) {
		console.log('content.find exception <' + err.name + '> : ' + err.message);
	}
}

function initialize() {
	var sapinitsuccesscb = {
			onsuccess : function () {
				console.log('Succeed to connect');
				ftInit(ftSuccessCb, function(err) {
					toastAlert('Failed to get File Transfer');
				});
			},
			ondevicestatus : function(status) {
				if (status == "DETACHED") {
					console.log('Detached remote peer device');
					clearList();
				} else if (status == "ATTACHED") {
					console.log('Attached remote peer device');
					reconnect();
				}
			}
	};

	sapInit(sapinitsuccesscb, function(err) {
		toastAlert('Failed to connect to service :'+err.name);
	});
}

function cancelFile() {
	ftCancel(gTransferId,function() {
		console.log('Succeed to cancel file');
		showMain();
	}, function(err) {
		toastAlert('Failed to cancel File');
	});
}

function sendFile(path) {
	ftSend(path, function(id) {
		console.log('Succeed to send file');
		gTransferId = id;
		tau.changePage('#sendPage');
		$('#sendprogress').attr('value', 0);
	}, function(err) {
		showMain('Failed to send File');
	});
}

(function() {
	window.addEventListener('tizenhwkey', function(e) {
		/* For the flick down gesture */
		if (e.keyName == "back")
		{
			var page = document.getElementsByClassName('ui-page-active')[0],
				pageid = page ? page.id : " ";
			if (pageid === "main") {
				/* When a user flicks down, the application exits */
				//tizen.application.getCurrentApplication().exit();
				window.location.href="IndexBilel.html";
			}
			else {
				cancelFile();
				window.history.back();
			}
		}
	});

	window.addEventListener('load', function(ev) {
		initialize();
		//$('.ui-listview').append('<input type="button" class="ui-btn ui-inline" value="Connect" onclick="initialize();" style="width:100%;"/>');
	});
}());

(function(ui) {
	var closePopup = ui.closePopup.bind(ui);
	var toastPopup = document.getElementById('popupToast');
	toastPopup.addEventListener('popupshow', function(ev){
		setTimeout(closePopup, 3000);
	}, false);
})(window.tau);