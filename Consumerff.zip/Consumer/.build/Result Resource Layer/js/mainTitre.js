
$(window).load(function(){
	document.addEventListener('tizenhwkey', function(e) {
        if(e.keyName == "back"){
        
            window.location.href="IndexBilel.html";
        	// tizen.application.getCurrentApplication().exit();
			}});
	
});
function showacc( ) {
	connect();
	$("#acceuil").show();
	$("#gestionphone").hide();
	$("#gestionm").hide();
	$("#gestioni").hide();
	$("#reconizemusic").hide();
	$("#reconizeimage").hide();
	$("#sharing").hide();
	
}

function showM( ) {
	$("#acceuil").hide();
	/*$("#gestionphone").hide();
	$("#gestionm").hide();
	$("#gestioni").hide();
	$("#reconizemusic").show();
	$("#reconizeimage").hide();
	$("#sharing").hide();*/
	window.location.href="index.html"
	
}
function showG( ) {
	$("#acceuil").hide();
	
	/*$("#gestionphone").show();
	$("#gestionm").hide();
	$("#gestioni").hide();
	$("#reconizemusic").hide();
	$("#reconizeimage").hide();
	$("#sharing").hide();*/
	window.location.href="IndexH.html"
	
}
function showI( ) {
	$("#acceuil").hide();
	$("#gestionphone").hide();
	$("#gestionm").hide();
	$("#gestioni").hide();
	$("#reconizemusic").hide();
	$("#reconizeimage").show();
	$("#sharing").hide();
	
}
function showS( ) {
	$("#acceuil").hide();
	$("#gestionphone").hide();
	$("#gestionm").hide();
	$("#gestioni").hide();
	$("#reconizemusic").hide();
	$("#reconizeimage").hide();
	$("#sharing").show();
	
}
function showGI( ) {
	$("#acceuil").hide();
	$("#gestionphonea").hide();
	$("#gestionm").hide();
	$("#gestioni").show();
	$("#reconizemusic").hide();
	$("#reconizeimage").hide();
	$("#sharing").hide();
	
}
function showGM( ) {
	$("#acceuil").hide();
	$("#gestionphonea").hide();
	$("#gestionm").show();
	$("#gestioni").hide();
	$("#reconizemusic").hide();
	$("#reconizeimage").hide();
	$("#sharing").hide();
	
}